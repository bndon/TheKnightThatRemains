<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Background2" tilewidth="16" tileheight="16" tilecount="527" columns="31">
 <image source="Background2.png" width="496" height="272"/>
</tileset>
