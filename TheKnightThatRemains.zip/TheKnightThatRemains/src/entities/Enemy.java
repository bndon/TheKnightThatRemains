package entities;

import static utils.Constants.EnemyConstants.*;
import static utils.HelpMethods.*;
import static utils.Constants.Directions.*;
import java.awt.geom.Rectangle2D;
import main.Game;

public abstract class Enemy extends Entity {
    protected int enemyType;
    protected boolean firstUpdate = true;
    protected int walkDir = LEFT;
    protected int tileY;
    protected float attackDistance = Game.TILES_SIZE; 
    protected boolean active = true;
    protected boolean attackChecked;
    
    protected int maxHealth;
    protected int currentHealth;
    protected float walkSpeed = 0.35f * Game.SCALE;

    protected float airSpeed;
    protected float gravity = 0.04f * Game.SCALE;
    
    protected boolean inAir = false; 
    
    protected int state = IDLE;
    protected int aniIndex, aniTick, aniSpeed = 25;

    public Enemy(float x, float y, int width, int height, int enemyType) {
        super(x, y, width, height);
        this.enemyType = enemyType;
        initHitbox(x, y, width, height);
        maxHealth = 2; 
        currentHealth = maxHealth;
    }

    protected void firstUpdateCheck(int[][] lvlData) {
        if (!IsEntityOnFloor(hitbox, lvlData))
            inAir = true;
        firstUpdate = false;
    }

    protected void updateInAir(int[][] lvlData) {
        if (CanMoveHere(hitbox.x, hitbox.y + airSpeed, hitbox.width, hitbox.height, lvlData)) {
            hitbox.y += airSpeed;
            airSpeed += gravity;
        } else {
            inAir = false;
            hitbox.y = GetEntityYPosUnderRoofOrAboveFloor(hitbox, airSpeed);
            tileY = (int) (hitbox.y / Game.TILES_SIZE);
        }
    }

    protected boolean move(int[][] lvlData) {
        float xSpeed = 0;
        if (walkDir == LEFT) xSpeed = -walkSpeed;
        else xSpeed = walkSpeed;

        if (CanMoveHere(hitbox.x + xSpeed, hitbox.y, hitbox.width, hitbox.height, lvlData)) {
            if (isFloor(hitbox, xSpeed, lvlData)) {
                hitbox.x += xSpeed;
                return true;
            }
        }
        return false; 
    }
    
    protected boolean isFloor(Rectangle2D.Float hitbox, float xSpeed, int[][] lvlData) {
        if (walkDir == LEFT)
            return isSolid(hitbox.x + xSpeed, hitbox.y + hitbox.height + 1, lvlData);
        else 
            return isSolid(hitbox.x + hitbox.width + xSpeed, hitbox.y + hitbox.height + 1, lvlData);
    }

    protected void changeWalkDir() {
        if (walkDir == LEFT) walkDir = RIGHT;
        else walkDir = LEFT;
    }

    protected void newState(int enemyState) {
        this.state = enemyState;
        aniTick = 0;
        aniIndex = 0;
    }
    
    // --- FIX: STOP DEAD ANIMATION LOOP ---
    public void hurt(int amount) {
        if (currentHealth <= 0) return; // Ignore hit if already dead
        
        currentHealth -= amount;
        if (currentHealth <= 0) {
            newState(DEAD); 
        } else {
            newState(HIT); 
        }
    }
    
    protected void checkPlayerHit(Rectangle2D.Float attackBox, Player player) {
        if(attackBox.intersects(player.getHitbox())) {
            player.damage(1, hitbox.x);
        }
        attackChecked = true;
    }

    protected void updateAnimationTick() {
        aniTick++;
        if (aniTick >= aniSpeed) {
            aniTick = 0;
            aniIndex++;
            if (aniIndex >= GetSpriteAmount(enemyType, state)) {
                aniIndex = 0;
                
                if(state == ATTACK_1 || state == HIT) 
                    state = IDLE;
                else if(state == DEAD) 
                    active = false; 
            }
        }
    }
    
    // Getters/Setters needed for Boss/Manager
    public void changeWalkDirLeft() { this.walkDir = LEFT; }
    public void changeWalkDirRight() { this.walkDir = RIGHT; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    public int getState() { return state; }
    public int getAniIndex() { return aniIndex; }
    
    public int flipX() { return (walkDir == RIGHT) ? 0 : width; }
    public int flipW() { return (walkDir == RIGHT) ? 1 : -1; }
}