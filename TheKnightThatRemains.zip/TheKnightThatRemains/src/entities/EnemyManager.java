package entities;

import java.awt.Graphics;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import levels.Level;
import main.Game;
import utils.LoadSave;
import utils.TMXLoader.TMXObject;
import static utils.Constants.EnemyConstants.*;

public class EnemyManager {

    // --- CORE REFERENCES ---
    private Game game;

    // --- ENEMY SPRITE ARRAYS ---
    private BufferedImage[][] skeletonArr;
    private BufferedImage[][] bossArr;

    // --- ENEMY INSTANCES ---
    private ArrayList<Skeleton> skeletons = new ArrayList<>();
    private KnightBoss boss; 

    // --- CONSTRUCTOR ---
    // Loads enemy and boss sprite atlases
    public EnemyManager(Game game) {
        this.game = game;
        loadEnemyImgs();
        loadBossImgs();
    }
    
    // --- RESET ALL ENEMIES ---
    // Used when restarting level or loading from checkpoint
    public void resetAllEnemies(Level level) {
        loadEnemies(level); 
    }

    // --- LOAD ENEMIES FROM LEVEL ---
    // Supports both TMX object layers and tile-based layers
    public void loadEnemies(Level level) {
        skeletons.clear();
        boss = null; 
        
        // --- LOAD SKELETONS (TMX OBJECTS) ---
        List<TMXObject> enemyObjs = level.getObjects("EnemyPos");
        if (enemyObjs != null && !enemyObjs.isEmpty()) {
            for (TMXObject o : enemyObjs)
                skeletons.add(new Skeleton(o.x * Game.SCALE, (o.y * Game.SCALE) - (25 * Game.SCALE)));
        } 
        // --- FALLBACK: TILE-BASED ENEMY LAYER ---
        else {
            int[][] enemyGrid = level.getLayerData("EnemyPos");
            if (enemyGrid != null) {
                for (int y = 0; y < level.getHeight(); y++) {
                    for (int x = 0; x < level.getWidth(); x++) {
                        if (enemyGrid[y][x] != 0)
                            skeletons.add(new Skeleton(x * Game.TILES_SIZE, (y * Game.TILES_SIZE) - (20 * Game.SCALE)));
                    }
                }
            }
        }

        // --- LOAD BOSS SPAWN (TMX OBJECT) ---
        List<TMXObject> bossSpawns = level.getObjects("BossSpawn");
        if (bossSpawns != null && !bossSpawns.isEmpty()) {
            TMXObject b = bossSpawns.get(0);
            boss = new KnightBoss(b.x * Game.SCALE, (b.y * Game.SCALE) - (15 * Game.SCALE));
        } 
        // --- FALLBACK: TILE-BASED BOSS SPAWN ---
        else {
            int[][] bossGrid = level.getLayerData("BossSpawn");
            if (bossGrid != null) {
                outer:
                for (int y = 0; y < level.getHeight(); y++) {
                    for (int x = 0; x < level.getWidth(); x++) {
                        if (bossGrid[y][x] != 0) {
                            boss = new KnightBoss(x * Game.TILES_SIZE, (y * Game.TILES_SIZE) - (15 * Game.SCALE));
                            break outer;
                        }
                    }
                }
            }
        }
    }

    // --- UPDATE ALL ENEMIES ---
    public void update(int[][] lvlData, Player player) {
        for (Skeleton s : skeletons) {
            if (s.isActive()) {
                s.update(lvlData, player);
                // --- FIX: REMOVED BODY COLLISION CHECK ---
            }
        }
            
        if (boss != null && boss.isActive()) {
            boss.update(lvlData, player);
            // --- FIX: REMOVED BODY COLLISION CHECK ---
            
            // --- BOSS DEATH TRIGGER ---
            if (boss.isDeathAnimComplete()) {
                game.triggerBossEnding();
                boss.setActive(false);
            }
        }
    }

    // --- RENDER ALL ENEMIES ---
    public void draw(Graphics g, int xLvlOffset, int yLvlOffset) {
        drawSkeletons(g, xLvlOffset, yLvlOffset);
        if (boss != null && boss.isActive()) drawBoss(g, boss, xLvlOffset, yLvlOffset);
    }

    // --- RENDER SKELETONS ---
    private void drawSkeletons(Graphics g, int xLvlOffset, int yLvlOffset) {
        for (Skeleton s : skeletons)
            if (s.isActive()) drawEnemy(g, s, skeletonArr, xLvlOffset, yLvlOffset);
    }
    
    // --- RENDER BOSS ---
    private void drawBoss(Graphics g, KnightBoss b, int xLvlOffset, int yLvlOffset) {
        int width = (int) (41 * Game.SCALE);
        int height = (int) (31 * Game.SCALE);
        int xOffset = (int) (11 * Game.SCALE);
        int yOffset = (int) (11 * Game.SCALE); 

        g.drawImage(bossArr[b.getState()][b.getAniIndex()],
                (int) (b.getHitbox().x - xLvlOffset - xOffset) + b.flipX(),
                (int) (b.getHitbox().y - yLvlOffset - yOffset),
                width * b.flipW(), height, null);

        b.drawHealthBar(g, xLvlOffset, yLvlOffset);
    }

    // --- GENERIC ENEMY DRAW METHOD ---
    private void drawEnemy(Graphics g, Enemy e, BufferedImage[][] sprites, int xOff, int yOff) {
        g.drawImage(sprites[e.getState()][e.getAniIndex()],
                (int) (e.getHitbox().x - xOff - SKELETON_DRAWOFFSET_X) + e.flipX(),
                (int) (e.getHitbox().y - yOff - SKELETON_DRAWOFFSET_Y),
                SKELETON_WIDTH * e.flipW(), SKELETON_HEIGHT, null);
    }
    
    // --- PLAYER ATTACK → ENEMY HIT CHECK ---
    public void checkEnemyHit(Rectangle2D.Float attackBox) {
        for (Skeleton s : skeletons)
            if (s.isActive() && attackBox.intersects(s.getHitbox())) s.hurt(1);
            
        if (boss != null && boss.isActive() && attackBox.intersects(boss.getHitbox()))
            boss.hurt(1);
    }

    // --- LOAD SKELETON SPRITES ---
    private void loadEnemyImgs() {
        skeletonArr = new BufferedImage[6][13]; 
        BufferedImage temp = LoadSave.GetSpriteAtlas(LoadSave.SKELETON_ATLAS); 
        for (int j = 0; j < skeletonArr.length; j++)
            for (int i = 0; i < skeletonArr[j].length; i++)
                skeletonArr[j][i] = temp.getSubimage(i * 96, j * 64, 96, 64);
    }
    
    // --- LOAD BOSS SPRITES ---
    private void loadBossImgs() {
        bossArr = new BufferedImage[16][11]; 
        BufferedImage temp = LoadSave.GetSpriteAtlas(LoadSave.BOSS_ATLAS); 
        for (int j = 0; j < bossArr.length; j++)
            for (int i = 0; i < bossArr[j].length; i++)
                bossArr[j][i] = temp.getSubimage(i * 41, j * 31, 41, 31);
    }

    // --- BOSS ACCESSOR ---
    public KnightBoss getBoss() { return boss; }
}
