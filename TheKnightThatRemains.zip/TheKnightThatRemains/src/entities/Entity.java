package entities;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.geom.Rectangle2D;

public abstract class Entity {

	// --- POSITION & SIZE VARIABLES ---
	protected float x, y;
	protected int width, height;

	// --- COLLISION / HITBOX ---
	protected Rectangle2D.Float hitbox;
	
	// --- ENTITY CONSTRUCTOR ---
	// Initializes base position and size for all entities
	public Entity(float x, float y, int width, int height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	
	// --- HITBOX DEBUG RENDERING ---
	// Draws the hitbox outline (used only for debugging)
	protected void drawHitbox(Graphics g) {
		g.setColor(Color.red);
		g.drawRect((int) hitbox.x, (int) hitbox.y, (int) hitbox.width, (int) hitbox.height);
	}
	
	// --- HITBOX INITIALIZATION ---
	// Creates and assigns a rectangular hitbox
	protected void initHitbox(float x, float y, float width, float height) {
		hitbox = new Rectangle2D.Float(x, y, width, height);
	}
	
	// --- HITBOX ACCESSOR ---
	// Returns the entity's hitbox for collision checks
	public Rectangle2D.Float getHitbox() {
		return hitbox;
	}
}
