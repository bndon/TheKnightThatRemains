package entities;

import static utils.Constants.PlayerConstants.*; 
import static utils.Constants.Directions.*;
import static utils.HelpMethods.*; 

import java.awt.Color;
import java.awt.Graphics;
import java.awt.geom.Rectangle2D;
import main.Game;

public class KnightBoss extends Enemy {

    // --- ATTACK & COMBAT ---
    private Rectangle2D.Float attackBox;
    private int attackCooldown = 0;

    // --- FIGHT STATE ---
    private boolean activeFight = false; 
    private boolean deathAnimComplete = false;

    // --- ROLL MECHANIC ---
    private boolean isRolling = false;
    private int rollTick = 0;
    private int rollDuration = 40;
    
    // --- JUMP LOGIC ---
    private float jumpSpeed = -2.5f * Game.SCALE; 

    // --- CONSTRUCTOR ---
    public KnightBoss(float x, float y) {
        super(x, y, (int)(41 * Game.SCALE), (int)(31 * Game.SCALE), 999); 
        initHitbox(x, y, (int)(12 * Game.SCALE), (int)(20 * Game.SCALE));
        initAttackBox();
        
        // --- BASE STATS ---
        this.maxHealth = 15; 
        this.currentHealth = maxHealth;
        this.walkDir = LEFT; 
        this.walkSpeed = 0.5f * Game.SCALE; 
        this.state = IDLE; 
        this.gravity = 0.04f * Game.SCALE;
    }

    // --- ATTACK HITBOX SETUP ---
    private void initAttackBox() {
        attackBox = new Rectangle2D.Float(x, y, (int)(20 * Game.SCALE), (int)(20 * Game.SCALE));
    }

    // --- FIGHT ACTIVATION ---
    public void activateFight() { this.activeFight = true; }
    public boolean isActiveFight() { return activeFight; }

    // --- RESET BOSS STATE ---
    public void resetBoss() {
        this.currentHealth = maxHealth;
        this.activeFight = false;
        this.deathAnimComplete = false;
        this.state = IDLE;
        this.active = true;
        this.firstUpdate = true;
    }

    // --- UPDATE ENTRY POINT ---
    public void update(int[][] lvlData, Player player) {
        if (!activeFight) return;
        updateBehavior(lvlData, player);
        updateAnimationTick();
        updateAttackBox();
    }
    
    // --- ATTACK BOX POSITION UPDATE ---
    private void updateAttackBox() {
        if (walkDir == RIGHT) attackBox.x = hitbox.x + hitbox.width + (int)(Game.SCALE * 2);
        else attackBox.x = hitbox.x - attackBox.width - (int)(Game.SCALE * 2);
        attackBox.y = hitbox.y; 
    }

    // --- MAIN AI LOGIC ---
    private void updateBehavior(int[][] lvlData, Player player) {
        if (firstUpdate) firstUpdateCheck(lvlData);
        
        // --- GRAVITY & AIR MOVEMENT ---
        if (inAir) {
            if (CanMoveHere(hitbox.x, hitbox.y + airSpeed, hitbox.width, hitbox.height, lvlData)) {
                hitbox.y += airSpeed;
                airSpeed += gravity;
            } else {
                hitbox.y = GetEntityYPosUnderRoofOrAboveFloor(hitbox, airSpeed);
                if (airSpeed > 0) inAir = false; 
                else airSpeed = 0.5f * Game.SCALE;
            }
        } else {
            if (!IsEntityOnFloor(hitbox, lvlData)) inAir = true;
        }
        
        // --- HIT STUN ---
        if (state == HIT_FRONT && currentHealth > 0) return;

        // --- DEATH HANDLING ---
        if (currentHealth <= 0) {
            if (state != HIT_FRONT) {
                state = HIT_FRONT;
                aniIndex = 0;
                aniTick = 0;
            }
            return; 
        }

        // --- ROLL MOVEMENT ---
        if (isRolling) {
            rollTick++;
            float speed = (walkDir == RIGHT) ? 2.0f * Game.SCALE : -2.0f * Game.SCALE;
            if (CanMoveHere(hitbox.x + speed, hitbox.y, hitbox.width, hitbox.height, lvlData)) {
                hitbox.x += speed;
            }
            if (rollTick >= rollDuration) {
                isRolling = false;
                state = IDLE;
            }
            return;
        }

        // --- ATTACK EXECUTION ---
        if (state == ATTACK_1 || state == ATTACK_2 || state == ATTACK_3) {
            if (aniIndex == 1 && !attackChecked) checkPlayerHit(attackBox, player);
            return;
        }

        // --- ATTACK COOLDOWN ---
        if (attackCooldown > 0) attackCooldown--;

        // --- FACE PLAYER ---
        if (player.getHitbox().x > hitbox.x) walkDir = RIGHT;
        else walkDir = LEFT;

        float dist = Math.abs(player.getHitbox().x - hitbox.x);
        float attackRange = 30 * Game.SCALE; 

        // --- ATTACK OR CHASE ---
        if (dist <= attackRange) {
            if (attackCooldown <= 0) performAction();
            else state = IDLE;
        } else {
            state = RUN; 
            move(lvlData);
            
            // --- JUMP DECISION ---
            if (activeFight && !inAir) {
                boolean wallAhead = !CanMoveHere(hitbox.x + ((walkDir == RIGHT) ? walkSpeed : -walkSpeed) * 10, hitbox.y, hitbox.width, hitbox.height, lvlData);
                boolean playerHigh = player.getHitbox().y < hitbox.y - (Game.TILES_SIZE * 2);
                
                if (wallAhead || (playerHigh && dist < 100 * Game.SCALE)) {
                    inAir = true;
                    airSpeed = jumpSpeed;
                }
            }
        }
    }

    // --- HORIZONTAL MOVEMENT ---
    @Override
    protected boolean move(int[][] lvlData) {
        float xSpeed = 0;
        if (walkDir == LEFT) xSpeed = -walkSpeed;
        else xSpeed = walkSpeed;

        if (CanMoveHere(hitbox.x + xSpeed, hitbox.y, hitbox.width, hitbox.height, lvlData)) {
            if (isFloor(hitbox, xSpeed, lvlData) || inAir) { 
                hitbox.x += xSpeed;
                return true;
            }
        }
        return false; 
    }
    
    // --- DAMAGE HANDLING ---
    @Override
    public void hurt(int amount) {
        if (currentHealth <= 0) return;
        currentHealth -= amount;
        state = HIT_FRONT; 
        aniIndex = 0;
        aniTick = 0;
    }

    // --- HEALTH BAR RENDER ---
    public void drawHealthBar(Graphics g, int xLvlOffset, int yLvlOffset) {
        int x = (int) (hitbox.x - xLvlOffset - 10);
        int y = (int) (hitbox.y - yLvlOffset - 15);
        int width = (int) (hitbox.width + 20);
        g.setColor(Color.RED);
        g.fillRect(x, y, width, 5);
        g.setColor(Color.GREEN);
        int currentWidth = (int) ((currentHealth / (float) maxHealth) * width);
        g.fillRect(x, y, currentWidth, 5);
        g.setColor(Color.BLACK);
        g.drawRect(x, y, width, 5);
    }

    // --- RANDOM ACTION SELECTION ---
    private void performAction() {
        double rand = Math.random();
        if (rand < 0.2) {
            isRolling = true;
            rollTick = 0;
            state = ROLL;
        } else if (rand < 0.6) {
            state = ATTACK_1;
            attackCooldown = 150; 
        } else {
            state = ATTACK_2;
            attackCooldown = 180; 
        }
        aniIndex = 0;
        aniTick = 0;
        attackChecked = false;
    }
    
    // --- ANIMATION UPDATE ---
    @Override
    protected void updateAnimationTick() {
        aniTick++;
        if (aniTick >= aniSpeed) {
            aniTick = 0;
            aniIndex++;
            if (aniIndex >= GetSpriteAmount(state)) {
                aniIndex = 0;
                if (state == HIT_FRONT && currentHealth <= 0) deathAnimComplete = true; 
                else if (state == ATTACK_1 || state == ATTACK_2 || state == ROLL || state == HIT_FRONT) state = IDLE;
            }
        }
    }
    
    // --- STATE ACCESSORS & FLIP ---
    public boolean isDeathAnimComplete() { return deathAnimComplete; }
    @Override public int flipX() { return (walkDir == RIGHT) ? 0 : (int)(41 * Game.SCALE); }
    @Override public int flipW() { return (walkDir == RIGHT) ? 1 : -1; }
}
