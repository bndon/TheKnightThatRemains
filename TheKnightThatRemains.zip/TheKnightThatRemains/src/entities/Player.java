package entities;

import static utils.Constants.PlayerConstants.*;
import static utils.HelpMethods.*;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import main.Game;
import utils.LoadSave;

public class Player extends Entity {

    // --- GAME REFERENCE ---
    private Game game;

    // --- SPRITE DRAW OFFSETS ---
    private float xDrawOffset = 11 * Game.SCALE;
    private float yDrawOffset = 11 * Game.SCALE;

    // --- ANIMATION DATA ---
    private BufferedImage[][] animations;
    private int animTick, animIndex;
    private int animSpeed = 15;

    // --- PLAYER STATE / ACTION ---
    private int playerActions = IDLE;

    // --- SPRITE FLIP (DIRECTION) ---
    private int flipX = 0;
    private int flipW = 1;

    // --- HORIZONTAL MOVEMENT ---
    private float currentSpeed = 0;
    private float maxSpeed = 1.4f * Game.SCALE;
    private float walkSpeedLimit = 1.1f * Game.SCALE;
    private float acceleration = 0.02f * Game.SCALE;
    private float deceleration = 0.06f * Game.SCALE;

    // --- INPUT FLAGS ---
    private boolean moving = false;
    private boolean left, right, jumpKey, down;

    // --- JUMP LOCK (ANTI AUTO-JUMP) ---
    private boolean jumpConsumed = false;

    // --- VERTICAL MOVEMENT / GRAVITY ---
    private float airSpeed = 0f;
    private float gravity = 0.05f * Game.SCALE;
    private float jumpSpeed = -2.7f * Game.SCALE;
    private float fallSpeedCollision = 0.5f * Game.SCALE;
    private boolean inAir = false;

    // --- COYOTE TIME ---
    private int coyoteTime = 0;
    private int coyoteMax = 10;

    // --- COMBAT / ATTACK SYSTEM ---
    private boolean attacking = false;
    private int comboStep = 0;
    private boolean comboQueued = false;
    private Rectangle2D.Float attackBox;

    // --- ROLL / DODGE ---
    private boolean rolling = false;
    private float rollSpeed = 1.5f * Game.SCALE;

    // --- HEALTH SYSTEM ---
    private int maxHealth = 6;
    private int currentHealth = maxHealth;
    private int healthBarShowTimer = 0;
    private int healthBarDuration = 300;

    // --- IDLE ANIMATION TIMER ---
    private int idleTimer = 0;
    private int idleThreshold = 300;

    // --- LEVEL COLLISION DATA ---
    private int[][] lvlData;

    // --- CONSTRUCTOR ---
    public Player(float x, float y, int width, int height) {
        super(x, y, width, height);
        loadAnimations();
        initHitbox(x, y, 12 * Game.SCALE, 20 * Game.SCALE);
        initAttackBox();
    }

    // --- GAME INJECTION ---
    public void setGame(Game game) {
        this.game = game;
    }

    // --- ATTACK HITBOX INIT ---
    private void initAttackBox() {
        attackBox = new Rectangle2D.Float(x, y, (int)(20 * Game.SCALE), (int)(20 * Game.SCALE));
    }

    // --- MAIN UPDATE LOOP ---
    public void update() {

        // --- DEATH CHECK ---
        if (currentHealth <= 0) {
            if (game != null) game.triggerDeath();
            return;
        }

        // --- HEALTH BAR TIMER ---
        if (healthBarShowTimer > 0) healthBarShowTimer--;

        // --- IDLE SPECIAL ANIM LOGIC ---
        if (playerActions == IDLE && !moving && !attacking && !inAir && !rolling) {
            idleTimer++;
            if (idleTimer >= idleThreshold) {
                idleTimer = 0;
                if (Math.random() < 0.5) playerActions = SWORD_RAISE;
                else playerActions = SHIELD_RAISE;
                resetAnim();
            }
        } else idleTimer = 0;

        // --- CORE UPDATE CALLS ---
        updateMovement();
        updateAnimationTick();
        updateAnimationState();
        updateAttackBox();
    }

    // --- ATTACK HITBOX POSITION UPDATE ---
    private void updateAttackBox() {
        if (right || flipW == 1)
            attackBox.x = hitbox.x + hitbox.width + (int)(Game.SCALE * 2);
        else if (left || flipW == -1)
            attackBox.x = hitbox.x - attackBox.width - (int)(Game.SCALE * 2);
        attackBox.y = hitbox.y;
    }

    // --- RENDER PLAYER ---
    public void render(Graphics g, int xLvlOffset, int yLvlOffset) {
        g.drawImage(
            animations[playerActions][animIndex],
            (int)(hitbox.x - xDrawOffset) - xLvlOffset + flipX,
            (int)(hitbox.y - yDrawOffset) - yLvlOffset,
            width * flipW,
            height,
            null
        );

        if (healthBarShowTimer > 0) drawHealthBar(g, xLvlOffset, yLvlOffset);
    }

    // --- HEALTH BAR RENDER ---
    private void drawHealthBar(Graphics g, int xLvlOffset, int yLvlOffset) {
        int x = (int)(hitbox.x - xLvlOffset);
        int y = (int)(hitbox.y - yLvlOffset) - 8;
        g.setColor(Color.GRAY);
        g.fillRect(x, y, (int)hitbox.width, 3);
        g.setColor(Color.RED);
        g.fillRect(x, y, (int)((currentHealth / (float)maxHealth) * hitbox.width), 3);
    }

    // --- DAMAGE HANDLING ---
    public void damage(int amount, float enemyCenterX) {
        if (rolling) return;

        currentHealth -= amount;
        healthBarShowTimer = healthBarDuration;

        float playerCenterX = hitbox.x + hitbox.width / 2;
        boolean fromRight = enemyCenterX > playerCenterX;
        boolean facingRight = flipW == 1;

        playerActions = (facingRight == fromRight) ? HIT_FRONT : HIT_BACK;
        resetAnim();
        attacking = false;

        if (currentHealth < 0) currentHealth = 0;
    }

    // --- MOVEMENT & PHYSICS ---
    private void updateMovement() {

        // --- ROLL MOVEMENT ---
        if (rolling) {
            float speed = (flipW == 1) ? rollSpeed : -rollSpeed;
            if (CanMoveHere(hitbox.x + speed, hitbox.y, hitbox.width, hitbox.height, lvlData)) {
                hitbox.x += speed;
                if (!IsEntityOnFloor(hitbox, lvlData)) {
                    rolling = false;
                    inAir = true;
                }
            } else rolling = false;
            return;
        }

        // --- HIT STUN ---
        if (playerActions == HIT_FRONT || playerActions == HIT_BACK) {
            currentSpeed = 0;
            return;
        }

        // --- SPEED MODIFIER ---
        float speedMod = attacking ? 0.25f : 1.0f;

        // --- HORIZONTAL INPUT ---
        if (left) {
            currentSpeed -= acceleration;
            int flipOffset = (int)(width - hitbox.width - 2 * xDrawOffset);
            flipX = width - flipOffset;
            flipW = -1;
            if (currentSpeed < -maxSpeed * speedMod) currentSpeed = -maxSpeed * speedMod;
        } else if (right) {
            currentSpeed += acceleration;
            flipX = 0;
            flipW = 1;
            if (currentSpeed > maxSpeed * speedMod) currentSpeed = maxSpeed * speedMod;
        } else {
            if (currentSpeed > 0) currentSpeed = Math.max(0, currentSpeed - deceleration);
            else if (currentSpeed < 0) currentSpeed = Math.min(0, currentSpeed + deceleration);
        }

        // --- GROUND CHECK / COYOTE TIME ---
        if (!IsEntityOnFloor(hitbox, lvlData)) {
            inAir = true;
            if (coyoteTime > 0) coyoteTime--;
        } else if (inAir) {
            inAir = false;
            airSpeed = 0;
            coyoteTime = coyoteMax;
        }

        // --- JUMP LOGIC ---
        if (jumpKey && !jumpConsumed) {
            jumpConsumed = true;
            if (!inAir || coyoteTime > 0) jump();
        }
        if (!jumpKey) jumpConsumed = false;

        // --- VARIABLE JUMP HEIGHT ---
        if (inAir && airSpeed < 0 && !jumpKey) airSpeed += gravity * 2;

        // --- VERTICAL MOVEMENT ---
        if (inAir) {
            if (CanMoveHere(hitbox.x, hitbox.y + airSpeed, hitbox.width, hitbox.height, lvlData)) {
                hitbox.y += airSpeed;
                airSpeed += gravity;
            } else {
                hitbox.y = GetEntityYPosUnderRoofOrAboveFloor(hitbox, airSpeed);
                if (airSpeed > 0) resetInAir();
                else airSpeed = fallSpeedCollision;
            }
        }

        // --- HORIZONTAL COLLISION ---
        if (currentSpeed != 0) {
            if (CanMoveHere(hitbox.x + currentSpeed, hitbox.y, hitbox.width, hitbox.height, lvlData))
                hitbox.x += currentSpeed;
            else currentSpeed = 0;
        }
    }

    // --- FULL RESET ---
    public void resetAll() {
        resetDirBooleans();
        inAir = false;
        attacking = false;
        moving = false;
        rolling = false;
        playerActions = IDLE;
        currentSpeed = 0;
        currentHealth = maxHealth;
        hitbox.x = 100;
        hitbox.y = 200;
        jumpConsumed = false;
    }

    // --- JUMP ---
    private void jump() {
        inAir = true;
        airSpeed = jumpSpeed;
        coyoteTime = 0;
    }

    // --- LANDING RESET ---
    private void resetInAir() {
        inAir = false;
        airSpeed = 0;
        coyoteTime = coyoteMax;
    }

    // --- ANIMATION STATE UPDATE ---
    private void updateAnimationState() {
        int startAnim = playerActions;

        if (rolling) {
            playerActions = ROLL;
            if (startAnim != playerActions) resetAnim();
            return;
        }

        if (attacking || playerActions == HIT_FRONT || playerActions == HIT_BACK ||
            playerActions == SWORD_RAISE || playerActions == SHIELD_RAISE)
            return;

        if (inAir) playerActions = (airSpeed < 0) ? JUMP : FALL;
        else if (currentSpeed == 0) playerActions = IDLE;
        else if (Math.abs(currentSpeed) < walkSpeedLimit) playerActions = WALK;
        else playerActions = RUN;

        if (startAnim != playerActions) resetAnim();
    }

    // --- ANIMATION TICK UPDATE ---
    private void updateAnimationTick() {
        animTick++;
        animSpeed = rolling ? 4 : 15;

        if (animTick >= animSpeed) {
            animTick = 0;
            animIndex++;
            int maxFrames = GetSpriteAmount(playerActions);

            if (rolling) {
                if (animIndex >= maxFrames) {
                    animIndex = 0;
                    rolling = false;
                }
            } else if (attacking) {
                if (animIndex >= maxFrames) {
                    animIndex = maxFrames - 1;
                    processCombo();
                }
                if (animIndex == 1) checkEnemyHit();
            } else if (playerActions == HIT_FRONT || playerActions == HIT_BACK ||
                       playerActions == SWORD_RAISE || playerActions == SHIELD_RAISE) {
                if (animIndex >= maxFrames) {
                    playerActions = IDLE;
                    animIndex = 0;
                }
            } else if (animIndex >= maxFrames) animIndex = 0;
        }
    }

    // --- ENEMY HIT CHECK ---
    private void checkEnemyHit() {
        if (game != null)
            game.getEnemyManager().checkEnemyHit(attackBox);
    }

    // --- COMBO STATE MACHINE ---
    private void processCombo() {
        switch (comboStep) {
            case 1 -> {
                if (comboQueued) {
                    comboQueued = false;
                    comboStep = 2;
                    playerActions = ATTACK_2;
                    resetAnim();
                } else resetCombo();
            }
            case 2 -> {
                comboStep = 3;
                playerActions = ATTACK_2_PHASE_1_RECOVER;
                resetAnim();
            }
            case 3 -> {
                if (comboQueued) {
                    comboQueued = false;
                    comboStep = 4;
                    playerActions = ATTACK_3;
                    resetAnim();
                } else resetCombo();
            }
            case 4 -> resetCombo();
        }
    }

    // --- COMBO RESET ---
    private void resetCombo() {
        attacking = false;
        comboQueued = false;
        comboStep = 0;
        resetAnim();
    }

    // --- ANIMATION RESET ---
    private void resetAnim() {
        animTick = 0;
        animIndex = 0;
    }

    // --- ATTACK INPUT ---
    public void setAttacking(boolean pressed) {
        if (!pressed) return;
        if (!attacking && !rolling && playerActions != HIT_FRONT && playerActions != HIT_BACK) {
            attacking = true;
            comboStep = 1;
            playerActions = ATTACK_1;
            resetAnim();
            return;
        }
        comboQueued = true;
    }

    // --- ROLL INPUT ---
    public void setRoll(boolean pressed) {
        if (!pressed || rolling || attacking ||
            playerActions == HIT_FRONT || playerActions == HIT_BACK || inAir)
            return;
        rolling = true;
        resetAnim();
    }

    // --- POSITION SETTER ---
    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
        hitbox.x = x;
        hitbox.y = y;
        inAir = false;
        airSpeed = 0;
        currentSpeed = 0;
    }

    // --- INPUT SETTERS ---
    public void setLeft(boolean left) { this.left = left; }
    public void setRight(boolean right) { this.right = right; }
    public void setJump(boolean jump) { this.jumpKey = jump; }
    public void setDown(boolean down) { this.down = down; }
    public void resetDirBooleans() { left = right = jumpKey = down = false; }

    // --- STATE GETTERS ---
    public boolean isLeft() { return left; }
    public boolean isRight() { return right; }
    public boolean isDown() { return down; }
    public float getSpeed() { return currentSpeed; }
    public boolean isInAir() { return inAir; }

    // --- LOAD ANIMATIONS ---
    private void loadAnimations() {
        BufferedImage img = LoadSave.GetSpriteAtlas(LoadSave.PLAYER_ATLAS);
        animations = new BufferedImage[16][11];
        for (int y = 0; y < animations.length; y++)
            for (int x = 0; x < animations[y].length; x++)
                animations[y][x] = img.getSubimage(x * 41, y * 31, 41, 31);
    }

    // --- LEVEL DATA INJECTION ---
    public void loadLvlData(int[][] lvlData) {
        this.lvlData = lvlData;
    }
}
