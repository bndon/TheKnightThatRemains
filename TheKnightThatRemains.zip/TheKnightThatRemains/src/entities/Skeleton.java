package entities;

import static utils.Constants.EnemyConstants.*;
import static utils.Constants.Directions.*;
// Need HelpMethods for IsEntityOnFloor
import static utils.HelpMethods.*; 

import java.awt.geom.Rectangle2D;
import main.Game;

public class Skeleton extends Enemy {

    // --- ATTACK COLLISION BOXES ---
    private Rectangle2D.Float attackBox; 
    private Rectangle2D.Float attackCheck; 
    
    // --- PATROL & IDLE TIMERS ---
    private int patrolTimer;
    private int patrolDuration = 120;
    private int idleTimer;
    private int idleDuration = 60; 
    
    // --- ATTACK DELAY LOGIC ---
    private int attackDelayTimer = 0;
    private int attackDelay = 60; 

    public Skeleton(float x, float y) {
        super(x, y, SKELETON_WIDTH, SKELETON_HEIGHT, SKELETON);
        // --- HITBOX INITIALIZATION ---
        initHitbox(x, y, (int)(15 * Game.ENEMY_SCALE), (int)(46 * Game.ENEMY_SCALE));
        initAttackBox();
        this.state = IDLE;
    }
    
    // --- ATTACK BOX INITIALIZATION ---
    private void initAttackBox() {
        attackBox = new Rectangle2D.Float(x, y, (int)(40 * Game.SCALE), (int)(40 * Game.SCALE));
        attackCheck = new Rectangle2D.Float(x, y, (int)(32 * Game.SCALE), (int)(32 * Game.SCALE));
    }

    // --- MAIN UPDATE LOOP ---
    public void update(int[][] lvlData, Player player) {
        updateBehavior(lvlData, player);
        updateAnimationTick();
        updateAttackBox();
    }
    
    // --- ATTACK BOX POSITION UPDATE ---
    private void updateAttackBox() {
        if (walkDir == RIGHT) 
            attackBox.x = hitbox.x + hitbox.width + (int)(Game.SCALE * 2);
        else 
            attackBox.x = hitbox.x - attackBox.width - (int)(Game.SCALE * 2);
        
        attackBox.y = hitbox.y - (Game.SCALE * 5);
        
        if (walkDir == RIGHT) 
            attackCheck.x = hitbox.x + hitbox.width;
        else 
            attackCheck.x = hitbox.x - attackCheck.width;
            
        attackCheck.y = hitbox.y + (hitbox.height / 2) - (attackCheck.height / 2);
    }

    // --- AI STATE & BEHAVIOR LOGIC ---
    private void updateBehavior(int[][] lvlData, Player player) {
        if (firstUpdate) 
            firstUpdateCheck(lvlData);

        // --- GRAVITY & AIR STATE ---
        if (inAir) {
            updateInAir(lvlData);
        } else {
            // --- FLOOR CHECK SAFETY ---
            if (!IsEntityOnFloor(hitbox, lvlData)) {
                inAir = true;
                return;
            }

            switch (state) {

            // --- IDLE STATE LOGIC ---
            case IDLE:
                if (isPlayerCloseForAttack(player)) {
                    attackDelayTimer++;
                    if (attackDelayTimer >= attackDelay) {
                        attackDelayTimer = 0;
                        if (Math.random() < 0.5) newState(ATTACK_1);
                        else newState(ATTACK_2);
                    }
                } 
                else {
                    attackDelayTimer = 0;
                    idleTimer++;
                    if (idleTimer >= idleDuration) {
                        idleTimer = 0;
                        newState(WALK);
                        if (Math.random() > 0.5) changeWalkDir();
                    }
                }
                break;
                
            // --- WALK / PATROL LOGIC ---
            case WALK:
                if (canSeePlayer(lvlData, player)) {
                    turnTowardsPlayer(player);
                    if (isPlayerCloseForAttack(player)) {
                        newState(IDLE); 
                    }
                }
                
                boolean walked = move(lvlData);
                if (!walked) {
                    newState(IDLE);
                    changeWalkDir();
                } else {
                    patrolTimer++;
                    if (patrolTimer >= patrolDuration) {
                        patrolTimer = 0;
                        newState(IDLE);
                    }
                }
                break;
                
            // --- ATTACK 1 HIT CHECK ---
            case ATTACK_1:
                if (aniIndex == 0) attackChecked = false;
                if (aniIndex == 3 && !attackChecked) checkPlayerHit(attackBox, player);
                break;

            // --- ATTACK 2 HIT CHECK ---
            case ATTACK_2:
                if (aniIndex == 0) attackChecked = false;
                if (aniIndex == 3 && !attackChecked) checkPlayerHit(attackBox, player);
                break;
                
            // --- HIT / DEAD STATES ---
            case HIT:
            case DEAD:
                break;
            }
        }
    }
    
    // --- PLAYER DAMAGE CHECK ---
    @Override
    protected void checkPlayerHit(Rectangle2D.Float attackBox, Player player) {
        if(attackBox.intersects(player.getHitbox())) {
            player.damage(1, hitbox.x + hitbox.width / 2);
        }
        attackChecked = true;
    }

    // --- ANIMATION UPDATE ---
    @Override
    protected void updateAnimationTick() {
        aniTick++;
        if (aniTick >= aniSpeed) {
            aniTick = 0;
            aniIndex++;
            if (aniIndex >= GetSpriteAmount(enemyType, state)) {
                aniIndex = 0;
                
                if(state == ATTACK_1 || state == ATTACK_2 || state == HIT) 
                    state = IDLE;
                else if(state == DEAD) 
                    active = false; 
            }
        }
    }

    // --- LINE OF SIGHT CHECK ---
    private boolean canSeePlayer(int[][] lvlData, Player player) {
        int playerY = (int)(player.getHitbox().y / Game.TILES_SIZE);
        if (playerY == tileY)
            if (isPlayerInRange(player)) 
                return true;
        return false;
    }

    // --- HORIZONTAL RANGE CHECK ---
    private boolean isPlayerInRange(Player player) {
        int absValue = (int) Math.abs(player.getHitbox().x - hitbox.x);
        return absValue <= attackDistance * 5; 
    }

    // --- CLOSE-RANGE ATTACK CHECK ---
    private boolean isPlayerCloseForAttack(Player player) {
        return attackCheck.intersects(player.getHitbox());
    }

    // --- FACE PLAYER ---
    private void turnTowardsPlayer(Player player) {
        if (player.getHitbox().x > hitbox.x) walkDir = RIGHT;
        else walkDir = LEFT;
    }

    // --- DEBUG / ACCESSORS ---
    public Rectangle2D.Float getAttackBox() { return attackBox; }
    public Rectangle2D.Float getAttackCheck() { return attackCheck; }
}
