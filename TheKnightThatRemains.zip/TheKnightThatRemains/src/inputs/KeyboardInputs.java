package inputs;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import main.GamePanel;
import main.Gamestate;

public class KeyboardInputs implements KeyListener {
    
    // --- REFERENCE TO MAIN GAME PANEL ---
    private GamePanel gamePanel;

    // --- CONSTRUCTOR ---
    public KeyboardInputs(GamePanel gamePanel) {
        this.gamePanel = gamePanel; 
    }
    
    // --- UNUSED BUT REQUIRED BY KEYLISTENER ---
    @Override
    public void keyTyped(KeyEvent e) {}

    // --- KEY RELEASE HANDLING ---
    @Override
    public void keyReleased(KeyEvent e) {
        // Only process input when the game is actively playing
        if (Gamestate.state == Gamestate.PLAYING) {
            switch(e.getKeyCode()) {

            // --- STOP JUMP INPUT ---
            case KeyEvent.VK_W:
            case KeyEvent.VK_SPACE:
                gamePanel.getGame().getPlayer().setJump(false);
                break;

            // --- STOP MOVING LEFT ---
            case KeyEvent.VK_A:
                gamePanel.getGame().getPlayer().setLeft(false);
                break;

            // --- STOP CROUCH / DOWN ---
            case KeyEvent.VK_S:
                gamePanel.getGame().getPlayer().setDown(false);
                break;

            // --- STOP MOVING RIGHT ---
            case KeyEvent.VK_D:
                gamePanel.getGame().getPlayer().setRight(false);
                break;
            }
        }
    }
    
    // --- KEY PRESS HANDLING ---
    @Override
    public void keyPressed(KeyEvent e) {
        switch(Gamestate.state) {

        // --- MENU INPUT ---
        case MENU:
            if (e.getKeyCode() == KeyEvent.VK_ENTER)
                Gamestate.state = Gamestate.PLAYING;
            break;
            
        // --- IN-GAME INPUT ---
        case PLAYING:
            switch(e.getKeyCode()) {

            // --- ROLL / DODGE ---
            case KeyEvent.VK_SHIFT:
                gamePanel.getGame().getPlayer().setRoll(true);
                break;

            // --- JUMP ---
            case KeyEvent.VK_W:
            case KeyEvent.VK_SPACE:
                gamePanel.getGame().getPlayer().setJump(true);
                break;

            // --- MOVE LEFT ---
            case KeyEvent.VK_A:
                gamePanel.getGame().getPlayer().setLeft(true);
                break;

            // --- MOVE DOWN / CROUCH ---
            case KeyEvent.VK_S:
                gamePanel.getGame().getPlayer().setDown(true);
                break;

            // --- MOVE RIGHT ---
            case KeyEvent.VK_D:
                gamePanel.getGame().getPlayer().setRight(true);
                break;

            // --- PAUSE GAME ---
            case KeyEvent.VK_ESCAPE:
                gamePanel.getGame().togglePause();
                break;

            // --- INTERACT WITH OBJECTS ---
            case KeyEvent.VK_F:
                gamePanel.getGame().getObjectManager()
                         .checkInteraction(gamePanel.getGame().getPlayer());
                break;
            }
            break;
            
        // --- DIALOGUE INPUT ---
        case DIALOGUE:
            gamePanel.getGame().getDialogueOverlay().keyPressed(e);
            break;
            
        // --- CREDITS INPUT ---
        case CREDITS:
            gamePanel.getGame().getCreditsOverlay().keyPressed(e);
            break;
            
        // --- GAME OVER INPUT ---
        case GAMEOVER:
            gamePanel.getGame().getGameOverOverlay().keyPressed(e);
            break;
        }
    }
}
