package inputs;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import main.GamePanel;
import main.Gamestate;

public class MouseInput implements MouseListener, MouseMotionListener {

    // --- REFERENCE TO MAIN GAME PANEL ---
    private GamePanel gamePanel;
    
    // --- CONSTRUCTOR ---
    public MouseInput(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
    }

    // --- MOUSE PRESS HANDLING ---
    @Override
    public void mousePressed(MouseEvent e) {
        switch (Gamestate.state) {

        // --- MENU MOUSE INPUT ---
        case MENU:
            gamePanel.getGame().getMenu().mousePressed(e.getX(), e.getY());
            break;
            
        // --- IN-GAME MOUSE INPUT ---
        case PLAYING:
            if (gamePanel.getGame().isPaused()) {
                // --- PAUSE OVERLAY INPUT ---
                gamePanel.getGame().getPauseOverlay()
                         .mousePressed(e.getX(), e.getY());
            } else {
                // --- PLAYER COMBAT INPUT ---

                // Left Click → Attack
                if (e.getButton() == MouseEvent.BUTTON1) {
                    gamePanel.getGame().getPlayer().setAttacking(true);
                }

                // Right Click → Roll / Dodge
                if (e.getButton() == MouseEvent.BUTTON3) {
                    gamePanel.getGame().getPlayer().setRoll(true);
                }
            }
            break;
            
        default:
            break;
        }
    }

    // --- UNUSED MOUSE EVENTS ---
    @Override
    public void mouseClicked(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void mouseDragged(MouseEvent e) {}

    @Override
    public void mouseMoved(MouseEvent e) {}
}
