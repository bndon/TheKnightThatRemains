package levels;

import java.util.List;
import java.util.Map;
import utils.TMXLoader.TMXObject;

public class Level {

    // --- TILE LAYERS (RENDER & DATA) ---
    // Stores all tile layers loaded from the TMX map (by layer name)
    private final Map<String, int[][]> layers;

    // --- COLLISION LAYER ---
    // Cached reference to the collision layer for faster access
    private final int[][] collisionLayer;

    // --- OBJECT GROUPS ---
    // Stores TMX object layers (spawn points, triggers, interactables, etc.)
    private final Map<String, List<TMXObject>> objectGroups;
    
    // --- LEVEL DIMENSIONS (IN TILES) ---
    private final int width;
    private final int height;
    
    // --- LEVEL CONSTRUCTOR ---
    // Initializes tile layers, object groups, and validates collision data
    public Level(Map<String, int[][]> layers, Map<String, List<TMXObject>> objectGroups) {
        this.layers = layers;
        this.objectGroups = objectGroups;
        this.collisionLayer = layers.get("Collision");

        // --- SAFETY CHECK: COLLISION LAYER REQUIRED ---
        if (collisionLayer == null)
            throw new RuntimeException("Missing 'Collision' layer in Tiled Map!");

        // --- CALCULATE LEVEL SIZE ---
        height = collisionLayer.length;
        width = collisionLayer[0].length;
    }

    // --- RENDER LAYER ACCESSOR ---
    public Map<String, int[][]> getRenderLayers() { return layers; }

    // --- COLLISION DATA ACCESSOR ---
    public int[][] getCollisionData() { return collisionLayer; }
    
    // --- OBJECT GROUP ACCESS ---
    // Returns TMX objects for a specific object layer name
    public List<TMXObject> getObjects(String groupName) {
        return objectGroups.get(groupName);
    }
    
    // --- TILE LAYER ACCESS ---
    // Returns raw tile ID grid for a named layer
    public int[][] getLayerData(String layerName) {
        return layers.get(layerName);
    }

    // --- LEVEL DIMENSION ACCESSORS ---
    public int getWidth() { return width; }
    public int getHeight() { return height; }
}
