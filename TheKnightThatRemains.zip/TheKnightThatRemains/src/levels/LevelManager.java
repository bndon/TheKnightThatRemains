package levels;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import main.Game;
import utils.LoadSave;
import utils.TMXLoader;

public class LevelManager {

    // --- CORE GAME REFERENCE ---
    private final Game game;

    // --- CURRENTLY LOADED LEVEL ---
    private Level currentLevel;

    // --- TILESET STORAGE ---
    // Holds all tilesets used by the TMX map (supports multiple tilesets)
    private final List<Tileset> tilesets = new ArrayList<>();

    // --- INTERNAL TILESET STRUCT ---
    // firstGid: starting global tile ID
    // sprites: extracted tile images
    private static class Tileset {
        int firstGid;
        BufferedImage[] sprites;
    }

    // --- LEVEL MANAGER CONSTRUCTOR ---
    public LevelManager(Game game) {
        this.game = game;
        loadTMXLevel();
    }

    // --- TMX LEVEL LOADING ---
    // Loads TMX file, tilesets, and constructs Level object
    public void loadTMXLevel() {
        TMXLoader.TMXData data = TMXLoader.load("/level_01.tmx");
        loadTilesets(data.tilesets);
        currentLevel = new Level(data.layers, data.objectGroups);
    }

    // --- TILESET LOADING ---
    // Loads and slices all tilesets referenced by the TMX file
    private void loadTilesets(List<TMXLoader.TilesetInfo> infos) {
        for (TMXLoader.TilesetInfo info : infos) {

            // --- PATH SANITIZATION ---
            String temp = info.source.replace("//", "/");
            info.source = temp;
            
            BufferedImage atlas = LoadSave.GetSpriteAtlas(info.source);
            if (atlas == null) continue;

            // --- TILE EXTRACTION ---
            int tilesX = atlas.getWidth() / 16;
            int tilesY = atlas.getHeight() / 16;
            BufferedImage[] sprites = new BufferedImage[tilesX * tilesY];
            
            int index = 0;
            for (int y = 0; y < tilesY; y++) {
                for (int x = 0; x < tilesX; x++) {
                    sprites[index++] = atlas.getSubimage(x * 16, y * 16, 16, 16);
                }
            }

            // --- REGISTER TILESET ---
            Tileset ts = new Tileset();
            ts.firstGid = info.firstGid;
            ts.sprites = sprites;
            tilesets.add(ts);
        }

        // --- SORT TILESETS BY GID (DESCENDING) ---
        tilesets.sort((a, b) -> b.firstGid - a.firstGid);
    }

    // --- TILE LOOKUP BY GID ---
    // Converts global tile ID to correct tileset sprite
    private BufferedImage getTileSprite(int gid) {
        if (gid == 0) return null;

        for (Tileset ts : tilesets) {
            if (gid >= ts.firstGid) {
                int localIndex = gid - ts.firstGid;
                if (localIndex >= 0 && localIndex < ts.sprites.length)
                    return ts.sprites[localIndex];
            }
        }
        return null;
    }

    // --- LEVEL RENDERING ---
    // Draws all visible tile layers except logic-only layers
    public void draw(Graphics g, int xLvlOffset, int yLvlOffset) {
        if (currentLevel == null) return;
        
        for (String layerName : currentLevel.getRenderLayers().keySet()) {

            // --- NON-RENDERABLE LAYERS ---
            // Object / logic layers are skipped
            if (layerName.equals("EnemyPos") ||
                layerName.equals("BossSpawn") ||
                layerName.equals("BossCheck"))
                continue;
            
            int[][] layerData = currentLevel.getRenderLayers().get(layerName);

            // --- TILE DRAW LOOP ---
            for (int y = 0; y < currentLevel.getHeight(); y++) {
                for (int x = 0; x < currentLevel.getWidth(); x++) {
                    BufferedImage sprite = getTileSprite(layerData[y][x]);
                    if (sprite == null) continue;

                    g.drawImage(sprite, (x * Game.TILES_SIZE) - xLvlOffset, (y * Game.TILES_SIZE) - yLvlOffset, Game.TILES_SIZE, Game.TILES_SIZE, null);
                }
            }
        }
    }

    // --- UPDATE PLACEHOLDER ---
    public void update() {}

    // --- CURRENT LEVEL ACCESSOR ---
    public Level getCurrentLevel() { return currentLevel; }
}
