package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.List;

import entities.EnemyManager;
import entities.Player;
import levels.LevelManager;
import objects.ObjectManager;
import ui.CreditsOverlay;
import ui.DialogueOverlay;
import ui.GameOverOverlay;
import ui.Menu;
import ui.PauseOverlay;
import utils.HelpMethods;
import utils.LoadSave;
import utils.TMXLoader.TMXObject;

public class Game implements Runnable {

    // --- CORE WINDOW & THREAD ---
    private GameWindow gameWindow;
    private GamePanel gamePanel;
    private Thread gameThread;

    // --- GAME SYSTEM MANAGERS ---
    private EnemyManager enemyManager;
    private LevelManager levelManager;
    private ObjectManager objectManager;
    private Player player;

    // --- UI / OVERLAYS ---
    private Menu menu;
    private PauseOverlay pauseOverlay;
    private DialogueOverlay dialogueOverlay;
    private GameOverOverlay gameOverOverlay;
    private CreditsOverlay creditsOverlay;

    // --- GAME STATE VARS ---
    private boolean paused = false;
    private Point2D.Float respawnPoint;

    // --- CUTSCENE VARS ---
    private boolean cutsceneActive = false;
    private int cutsceneTick = 0;
    private float cutsceneCamX;
    private float newKnightX = -100;
    private int fadeAlpha = 0;
    private boolean nextKnightDialoguePlayed = false;

    // --- CUTSCENE ANIMATION ---
    private BufferedImage[][] nextKnightAnim;
    private int nkAnimTick, nkAnimIndex;

    // --- CUTSCENE TARGET POSITIONS ---
    private float nextKnightTargetX = 0;
    private float playerTargetX = 0;

    // --- BOSS TRIGGER & DIALOGUE ---
    private Rectangle2D.Float bossTrigger;
    private int dialogueStep = 0;

    // --- GAME CONSTANTS ---
    public final static int TILES_DEFAULT_SIZE = 16;
    public final static float SCALE = 2.0f;
    public final static float ENEMY_SCALE = 1.5f;
    public final static int TILES_IN_WIDTH = 30;
    public final static int TILES_IN_HEIGHT = 16;
    public final static int TILES_SIZE = (int) (TILES_DEFAULT_SIZE * SCALE);
    public final static int GAME_WIDTH = TILES_SIZE * TILES_IN_WIDTH;
    public final static int GAME_HEIGHT = TILES_SIZE * TILES_IN_HEIGHT;

    // --- LOOP SETTINGS ---
    private final int FPS_SET = 60;
    private final int UPS_SET = 100;

    // --- CAMERA VARS ---
    private int xLvlOffset, yLvlOffset;
    private float viewOffsetX = 0, viewOffsetY = 0;
    private int lvlTilesWide, lvlTilesHigh;
    private int maxLvlOffsetX, maxLvlOffsetY;

    // --- GAME CONSTRUCTOR ---
    public Game() {
        initClasses();
        gamePanel = new GamePanel(this);
        gameWindow = new GameWindow(gamePanel);
        gamePanel.requestFocus();
        startGameLoop();
    }

    // --- INITIALIZATION ---
    private void initClasses() {
        menu = new Menu(this);
        pauseOverlay = new PauseOverlay(this);
        dialogueOverlay = new DialogueOverlay(this);
        gameOverOverlay = new GameOverOverlay(this);
        creditsOverlay = new CreditsOverlay(this);

        levelManager = new LevelManager(this);
        enemyManager = new EnemyManager(this);
        objectManager = new ObjectManager(this);

        respawnPoint = new Point2D.Float(100, 200);
        player = new Player(respawnPoint.x, respawnPoint.y, (int)(41 * SCALE), (int)(31 * SCALE));
        player.setGame(this);

        loadGameData();
        loadLevel();
        loadNextKnightSprites();
        calcLvlOffset();
    }

    // --- RESET FOR NEW GAME ---
    public void resetGameForNewStart() {
        respawnPoint = new Point2D.Float(100, 200);
        player.setPosition(100, 200);
        player.resetAll();
        resetGame();

        enemyManager.resetAllEnemies(levelManager.getCurrentLevel());
        objectManager.resetAllObjects(levelManager.getCurrentLevel());
    }

    // --- SAVE / LOAD GAME DATA ---
    public void loadGameData() {
        float[] data = LoadSave.LoadGame();
        if (data != null) {
            respawnPoint = new Point2D.Float(data[0], data[1]);
            player.setPosition(data[0], data[1]);
            player.resetDirBooleans();

            enemyManager.resetAllEnemies(levelManager.getCurrentLevel());
            objectManager.resetAllObjects(levelManager.getCurrentLevel());

            dialogueStep = 0;
        }
    }

    // --- CUTSCENE SPRITES ---
    private void loadNextKnightSprites() {
        BufferedImage img = LoadSave.GetSpriteAtlas(LoadSave.NEXT_KNIGHT_ATLAS);
        nextKnightAnim = new BufferedImage[16][11];
        for (int y = 0; y < nextKnightAnim.length; y++) {
            for (int x = 0; x < nextKnightAnim[y].length; x++) {
                nextKnightAnim[y][x] = img.getSubimage(x * 41, y * 31, 41, 31);
            }
        }
    }

    // --- LEVEL LOADING & SETUP ---
    private void loadLevel() {
        levelManager.loadTMXLevel();
        player.loadLvlData(levelManager.getCurrentLevel().getCollisionData());
        enemyManager.loadEnemies(levelManager.getCurrentLevel());
        objectManager.loadObjects(levelManager.getCurrentLevel());

        // --- BOSS TRIGGER DETECTION ---
        List<TMXObject> checks = levelManager.getCurrentLevel().getObjects("BossCheck");
        if (checks != null && !checks.isEmpty()) {
            TMXObject t = checks.get(0);
            bossTrigger = new Rectangle2D.Float(t.x * SCALE, t.y * SCALE, t.width * SCALE, t.height * SCALE);
        } else {
            int[][] grid = levelManager.getCurrentLevel().getLayerData("BossCheck");
            if (grid != null) {
                outer: for (int y = 0; y < grid.length; y++) {
                    for (int x = 0; x < grid[0].length; x++) {
                        if (grid[y][x] != 0) {
                            bossTrigger = new Rectangle2D.Float(x * TILES_SIZE, 0, TILES_SIZE, GAME_HEIGHT);
                            break outer;
                        }
                    }
                }
            }
        }

        // --- FINAL CUTSCENE POSITIONS ---
        int[][] finalGrid = levelManager.getCurrentLevel().getLayerData("FinalPos");
        float minX = Float.MAX_VALUE;
        float maxX = Float.MIN_VALUE;
        boolean foundPositions = false;

        if (finalGrid != null) {
            for (int y = 0; y < finalGrid.length; y++) {
                for (int x = 0; x < finalGrid[0].length; x++) {
                    if (finalGrid[y][x] != 0) {
                        float worldX = x * TILES_SIZE;
                        if (worldX < minX) minX = worldX;
                        if (worldX > maxX) maxX = worldX;
                        foundPositions = true;
                    }
                }
            }
        }

        if (foundPositions) {
            nextKnightTargetX = minX;
            playerTargetX = maxX;
        } else if (bossTrigger != null) {
            nextKnightTargetX = bossTrigger.x;
            playerTargetX = bossTrigger.x + 300;
        }
    }

    // --- CAMERA BOUNDS CALCULATION ---
    private void calcLvlOffset() {
        lvlTilesWide = levelManager.getCurrentLevel().getWidth();
        maxLvlOffsetX = (lvlTilesWide - TILES_IN_WIDTH) * TILES_SIZE;

        lvlTilesHigh = levelManager.getCurrentLevel().getHeight();
        maxLvlOffsetY = (lvlTilesHigh - TILES_IN_HEIGHT) * TILES_SIZE;
    }

    // --- GAME LOOP START ---
    private void startGameLoop() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    // --- UPDATE LOGIC ---
    public void update() {
        if (cutsceneActive) {
            updateCutscene();
            return;
        }

        switch (Gamestate.state) {
        case MENU:
            menu.update();
            break;

        case PLAYING:
            if (!paused) {
                updateCamera();
                player.update();
                levelManager.update();
                enemyManager.update(levelManager.getCurrentLevel().getCollisionData(), player);
                objectManager.checkObjectTouched(player);

                // --- BOSS DIALOGUE & FIGHT ---
                if (bossTrigger != null && bossTrigger.intersects(player.getHitbox())) {
                    if (dialogueStep == 0) setCheckpoint(player.getHitbox());

                    if (dialogueStep == 0) {
                        dialogueStep = 1;
                        dialogueOverlay.showMessage("Boss: So, another seeker of the flame arrives... sadly, you will only find ash.");
                        player.resetDirBooleans();
                    } else if (dialogueStep == 1) {
                        dialogueStep = 2;
                        dialogueOverlay.showMessage("Player: Your watch is ended, Warden. I will break this curse.");
                    } else if (dialogueStep == 2) {
                        dialogueStep = 3;
                        if (enemyManager.getBoss() != null)
                            enemyManager.getBoss().activateFight();
                    }
                }
            } else {
                pauseOverlay.update();
            }
            break;

        case DIALOGUE:
            dialogueOverlay.update();
            break;

        case CREDITS:
            creditsOverlay.update();
            break;

        case GAMEOVER:
            gameOverOverlay.update();
            break;

        case QUIT:
            System.exit(0);
            break;
        }
    }

    // --- RENDERING ---
    public void render(Graphics g) {
        if (cutsceneActive) {
            levelManager.draw(g, (int)cutsceneCamX, yLvlOffset);
            enemyManager.draw(g, (int)cutsceneCamX, yLvlOffset);
            player.render(g, (int)cutsceneCamX, yLvlOffset);

            int walkAnimRow = nextKnightDialoguePlayed ? 0 : 1;
            g.drawImage(nextKnightAnim[walkAnimRow][nkAnimIndex],
                    (int)(newKnightX - cutsceneCamX),
                    (int)(player.getHitbox().y - yLvlOffset - (12 * SCALE)),
                    (int)(41 * SCALE), (int)(31 * SCALE), null);

            if (fadeAlpha > 0) {
                g.setColor(new Color(0, 0, 0, fadeAlpha));
                g.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
                if (fadeAlpha > 220) drawEndingPoem(g);
            }

            if (Gamestate.state == Gamestate.DIALOGUE) dialogueOverlay.draw(g);
            return;
        }

        switch (Gamestate.state) {
        case MENU:
            menu.draw(g);
            break;

        case PLAYING:
        case DIALOGUE:
        case GAMEOVER:
            levelManager.draw(g, xLvlOffset, yLvlOffset);
            objectManager.draw(g, xLvlOffset, yLvlOffset);
            enemyManager.draw(g, xLvlOffset, yLvlOffset);
            player.render(g, xLvlOffset, yLvlOffset);

            if (Gamestate.state == Gamestate.DIALOGUE) dialogueOverlay.draw(g);
            if (Gamestate.state == Gamestate.GAMEOVER) gameOverOverlay.draw(g);
            if (paused) pauseOverlay.draw(g);
            break;

        case CREDITS:
            menu.draw(g);
            creditsOverlay.draw(g);
            break;
        }
    }

    // --- ENDING POEM ---
    private void drawEndingPoem(Graphics g) {
        String[] poem = {
            "In shadows deep where embers die,",
            "The hero falls, a mournful cry.",
            "No glory found, no kingdom saved,",
            "Only the path the old ones paved.",
            "",
            "You take the mantle, heavy and cold,",
            "To repeat the story, forever told."
        };
        g.setColor(Color.WHITE);
        g.setFont(new Font("Times New Roman", Font.ITALIC, 28));
        int startY = GAME_HEIGHT / 2 - (poem.length * 30) / 2;
        for (int i = 0; i < poem.length; i++) {
            int textW = g.getFontMetrics().stringWidth(poem[i]);
            g.drawString(poem[i], GAME_WIDTH / 2 - textW / 2, startY + (i * 40));
        }
    }

    // --- GAME STATE HELPERS ---
    public void triggerDeath() {
        Gamestate.state = Gamestate.GAMEOVER;
        gameOverOverlay.reset();
    }

    public void respawnPlayer() {
        player.resetAll();
        player.setPosition(respawnPoint.x, respawnPoint.y);

        enemyManager.resetAllEnemies(levelManager.getCurrentLevel());
        objectManager.resetAllObjects(levelManager.getCurrentLevel());

        dialogueStep = 0;
        Gamestate.state = Gamestate.PLAYING;
    }

    public void setCheckpoint(Rectangle2D.Float box) {
        respawnPoint = new Point2D.Float(box.x, box.y - (20 * SCALE));
        LoadSave.SaveGame(respawnPoint.x, respawnPoint.y, 6);
    }

    // --- CUTSCENE CONTROL ---
    public void triggerBossEnding() {
        cutsceneActive = true;
        cutsceneTick = 0;
        cutsceneCamX = xLvlOffset;
        newKnightX = nextKnightTargetX - 200;
        nextKnightDialoguePlayed = false;
        fadeAlpha = 0;
    }

    private void updateCutscene() {
        if (Gamestate.state == Gamestate.DIALOGUE) {
            dialogueOverlay.update();
            return;
        }

        cutsceneTick++;

        if (!nextKnightDialoguePlayed) {
            if (newKnightX < nextKnightTargetX)
                newKnightX += 1.0f * SCALE;

            if (player.getHitbox().x < playerTargetX) {
                player.setRight(true);
                player.update();
            } else {
                player.resetDirBooleans();
                player.update();
            }

            float midPoint = (newKnightX + player.getHitbox().x) / 2;
            cutsceneCamX += (midPoint - (GAME_WIDTH / 2) - cutsceneCamX) * 0.05f;

            if (cutsceneTick % 15 == 0) {
                nkAnimIndex++;
                if (nkAnimIndex >= 6) nkAnimIndex = 0;
            }

            if (newKnightX >= nextKnightTargetX - 5) {
                nextKnightDialoguePlayed = true;
                dialogueOverlay.showMessage("Unknown: Another corpse... another warden. I shall take your burden.");
            }
        } else {
            fadeAlpha++;
            if (fadeAlpha > 255) fadeAlpha = 255;

            if (fadeAlpha == 255 && cutsceneTick > 1600) {
                initClasses();
                cutsceneActive = false;
                fadeAlpha = 0;
                Gamestate.state = Gamestate.MENU;
            }
        }
    }

    // --- CAMERA UPDATE ---
    private void updateCamera() {
        float playerCenterX = player.getHitbox().x + player.getHitbox().width / 2;
        float playerCenterY = player.getHitbox().y + player.getHitbox().height / 2;
        float smoothFactor = 0.05f;

        float targetViewOffsetX = 0;
        float targetViewOffsetY = 0;

        if (player.getSpeed() == 0 && !player.isInAir()) {
            if (player.isRight()) targetViewOffsetX = 60;
            else if (player.isLeft()) targetViewOffsetX = -60;
            if (player.isDown()) targetViewOffsetY = 150;
        }

        viewOffsetX += (targetViewOffsetX - viewOffsetX) * smoothFactor;
        viewOffsetY += (targetViewOffsetY - viewOffsetY) * smoothFactor;

        xLvlOffset = (int)(playerCenterX - (GAME_WIDTH / 2) + viewOffsetX);
        yLvlOffset = (int)(playerCenterY - (GAME_HEIGHT / 2) + viewOffsetY);

        if (xLvlOffset < 0) xLvlOffset = 0;
        else if (xLvlOffset > maxLvlOffsetX) xLvlOffset = maxLvlOffsetX;

        if (yLvlOffset < 0) yLvlOffset = 0;
        else if (yLvlOffset > maxLvlOffsetY) yLvlOffset = maxLvlOffsetY;
    }

    // --- GAME LOOP ---
    public void run() {
        double timePerFrame = 1000000000.0 / FPS_SET;
        double timePerUpdate = 1000000000.0 / UPS_SET;
        long previousTime = System.nanoTime();
        double deltaU = 0, deltaF = 0;

        while (true) {
            long currentTime = System.nanoTime();
            deltaU += (currentTime - previousTime) / timePerUpdate;
            deltaF += (currentTime - previousTime) / timePerFrame;
            previousTime = currentTime;

            if (deltaU >= 1) {
                update();
                deltaU--;
            }
            if (deltaF >= 1) {
                gamePanel.repaint();
                deltaF--;
            }
        }
    }

    // --- RESET & GETTERS ---
    public void resetGame() {
        player.resetAll();
        paused = false;
        dialogueStep = 0;
        cutsceneActive = false;
    }

    public void togglePause() { paused = !paused; }
    public void windowFocusLost() {
        if (Gamestate.state == Gamestate.PLAYING) {
            player.resetDirBooleans();
            paused = true;
        }
    }

    public Player getPlayer() { return player; }
    public Menu getMenu() { return menu; }
    public PauseOverlay getPauseOverlay() { return pauseOverlay; }
    public EnemyManager getEnemyManager() { return enemyManager; }
    public DialogueOverlay getDialogueOverlay() { return dialogueOverlay; }
    public ObjectManager getObjectManager() { return objectManager; }
    public GameOverOverlay getGameOverOverlay() { return gameOverOverlay; }
    public CreditsOverlay getCreditsOverlay() { return creditsOverlay; }
    public boolean isPaused() { return paused; }
    public void setPaused(boolean paused) { this.paused = paused; }
}
