package main;

import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import javax.swing.JFrame;

public class GameWindow {

    // --- WINDOW CORE ---
    private JFrame jframe;

    public GameWindow(GamePanel gamePanel) {
        jframe = new JFrame("The Knight That Remains");

        // --- FRAME SETUP ---
        jframe.setDefaultCloseOperation(jframe.EXIT_ON_CLOSE);
        jframe.setResizable(false);

        // --- PANEL ATTACHMENT ---
        jframe.add(gamePanel);
        jframe.pack();

        // --- WINDOW VISIBILITY & POSITION ---
        jframe.setLocationRelativeTo(null);
        jframe.setVisible(true);

        // --- WINDOW FOCUS HANDLING ---
        jframe.addWindowFocusListener(new WindowFocusListener() {

            @Override
            public void windowLostFocus(WindowEvent e) {
                gamePanel.getGame().windowFocusLost();
            }

            @Override
            public void windowGainedFocus(WindowEvent e) {
            }
        });
    }
}
