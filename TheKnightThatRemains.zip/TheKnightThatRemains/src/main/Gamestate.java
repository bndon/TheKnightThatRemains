package main;

public enum Gamestate {
	// --- GAME STATES ---
    PLAYING, MENU, OPTIONS, CREDITS, QUIT, DIALOGUE, CUTSCENE, GAMEOVER;
    
	// --- CURRENT GAME STATE ---
    public static Gamestate state = MENU;
}