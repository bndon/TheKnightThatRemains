package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Menu {

    // --- MENU CORE ---
    private Game game;
    private Rectangle playBtnBounds;
    private int btnX, btnY, btnRadius = 40;

    public Menu(Game game) {
        this.game = game;
        initButtons();
    }

    // --- BUTTON INITIALIZATION ---
    private void initButtons() {
        btnX = Game.GAME_WIDTH / 2;
        btnY = Game.GAME_HEIGHT / 2;
        playBtnBounds = new Rectangle(
                btnX - btnRadius,
                btnY - btnRadius,
                btnRadius * 2,
                btnRadius * 2
        );
    }

    // --- MENU UPDATE ---
    public void update() {
    }

    // --- MENU RENDER ---
    public void draw(Graphics g) {
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, Game.GAME_WIDTH, Game.GAME_HEIGHT);

        g.setColor(Color.WHITE);
        g.drawOval(btnX - btnRadius, btnY - btnRadius, btnRadius * 2, btnRadius * 2);

        int[] xPoints = { btnX - 10, btnX - 10, btnX + 20 };
        int[] yPoints = { btnY - 20, btnY + 20, btnY };
        g.fillPolygon(xPoints, yPoints, 3);

        g.drawString("CLICK TO START", btnX - 40, btnY + 60);
    }

    // --- INPUT HANDLING ---
    public void mousePressed(int x, int y) {
        if (playBtnBounds.contains(x, y)) {
            Gamestate.state = Gamestate.PLAYING;
        }
    }
}
