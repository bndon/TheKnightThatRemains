package main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;

import main.Gamestate;

public class PauseOverlay {

    // --- PAUSE OVERLAY CORE ---
    private Game game;
    private Rectangle resumeBtn, restartBtn, menuBtn, exitBtn;
    private int bgX, bgY, bgW, bgH;

    public PauseOverlay(Game game) {
        this.game = game;
        initBounds();
    }

    // --- UI BOUNDS INITIALIZATION ---
    private void initBounds() {
        bgW = 250;
        bgH = 300;
        bgX = Game.GAME_WIDTH / 2 - bgW / 2;
        bgY = Game.GAME_HEIGHT / 2 - bgH / 2;

        int btnW = 200;
        int btnH = 40;
        int gap = 15;
        int startY = bgY + 60;
        int btnX = bgX + 25;

        resumeBtn = new Rectangle(btnX, startY, btnW, btnH);
        restartBtn = new Rectangle(btnX, startY + btnH + gap, btnW, btnH);
        menuBtn = new Rectangle(btnX, startY + (btnH + gap) * 2, btnW, btnH);
        exitBtn = new Rectangle(btnX, startY + (btnH + gap) * 3, btnW, btnH);
    }

    // --- PAUSE OVERLAY UPDATE ---
    public void update() {}

    // --- PAUSE OVERLAY RENDER ---
    public void draw(Graphics g) {
        g.setColor(new Color(0, 0, 0, 150));
        g.fillRect(0, 0, Game.GAME_WIDTH, Game.GAME_HEIGHT);

        g.setColor(new Color(30, 30, 30));
        g.fillRect(bgX, bgY, bgW, bgH);
        g.setColor(Color.WHITE);
        g.drawRect(bgX, bgY, bgW, bgH);

        g.drawString("PAUSED", bgX + 100, bgY + 30);

        drawButton(g, resumeBtn, "Resume");
        drawButton(g, restartBtn, "Restart");
        drawButton(g, menuBtn, "Main Menu");
        drawButton(g, exitBtn, "Quit");
    }

    // --- BUTTON RENDER HELPER ---
    private void drawButton(Graphics g, Rectangle rect, String text) {
        g.setColor(new Color(60, 60, 60));
        g.fillRect(rect.x, rect.y, rect.width, rect.height);

        g.setColor(Color.BLACK);
        g.drawRect(rect.x, rect.y, rect.width, rect.height);

        g.setColor(Color.WHITE);
        int textX = rect.x + (rect.width / 2) - (text.length() * 3);
        g.drawString(text, textX, rect.y + 25);
    }

    // --- PAUSE MENU INPUT HANDLING ---
    public void mousePressed(int x, int y) {
        if (resumeBtn.contains(x, y)) {
            game.setPaused(false);
        } else if (restartBtn.contains(x, y)) {
            game.resetGame();
        } else if (menuBtn.contains(x, y)) {
            Gamestate.state = Gamestate.MENU;
            game.resetGame();
        } else if (exitBtn.contains(x, y)) {
            System.exit(0);
        }
    }
}
