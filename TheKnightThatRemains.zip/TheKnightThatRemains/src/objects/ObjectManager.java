package objects;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import entities.Player;
import levels.Level;
import main.Game;
import utils.TMXLoader.TMXObject;

public class ObjectManager {

    // --- OBJECT MANAGER CORE ---
    private Game game;
    private List<GameObject> loreObjects = new ArrayList<>();
    private List<GameObject> traps = new ArrayList<>();

    // --- GENERIC MAP OBJECT ---
    public static class GameObject {
        Rectangle2D.Float hitbox;
        String text;
        
        public GameObject(int x, int y, int w, int h, String text) {
            this.hitbox = new Rectangle2D.Float(x * Game.SCALE, y * Game.SCALE, w * Game.SCALE, h * Game.SCALE);
            this.text = text;
        }
        
        public GameObject(int x, int y, int w, int h, int yOffset) {
            this.hitbox = new Rectangle2D.Float(
                x * Game.SCALE,
                (y * Game.SCALE) + yOffset,
                w * Game.SCALE,
                (h * Game.SCALE) - yOffset
            );
            this.text = "";
        }
    }

    public ObjectManager(Game game) {
        this.game = game;
    }
    
    // --- FULL OBJECT RESET (ON RESPAWN / RELOAD) ---
    public void resetAllObjects(Level level) {
        loadObjects(level);
    }

    // --- LOAD ALL MAP OBJECTS FROM TMX ---
    public void loadObjects(Level level) {
        loreObjects.clear();
        traps.clear();
        
        String[] loreTexts = {
            "TURN BACK. There is no glory here, only the Curse. The dead do not rest. they wait for their replacement.",
            "The skeletons wear my kingdom's crest. Why do they salute me? Am I their commander, or their prisoner?",
            "I found a corpse today wearing my armor. It held my sword. I am still alive... aren't I?",
            "The dungeon doesn't just kill knights... it harvests them. The hunger I feel is not for food. It is for souls.",
            "I have failed. I am no longer a knight. I am the Warden. Kill me, or you will take my place in the Curse."
        };
        
        List<GameObject> tempList = new ArrayList<>();

        // --- INTERACTABLE OBJECTS (TMX OBJECT LAYER) ---
        List<TMXObject> interactables = level.getObjects("Interactable");
        if (interactables != null) {
            for (TMXObject o : interactables) {
                String t = o.properties.getOrDefault("text", "");
                tempList.add(new GameObject(o.x, o.y, o.width, o.height, t));
            }
        }
        
        // --- INTERACTABLE OBJECTS (TILE LAYER FALLBACK) ---
        int[][] interactGrid = level.getLayerData("Interactable");
        if (interactGrid != null) {
            for (int y = 0; y < interactGrid.length; y++) {
                for (int x = 0; x < interactGrid[0].length; x++) {
                    if (interactGrid[y][x] != 0) { 
                        tempList.add(new GameObject(
                            x * Game.TILES_DEFAULT_SIZE,
                            y * Game.TILES_DEFAULT_SIZE,
                            Game.TILES_DEFAULT_SIZE,
                            Game.TILES_DEFAULT_SIZE,
                            ""
                        ));
                    }
                }
            }
        }
        
        // --- LORE ASSIGNMENT ORDERING ---
        tempList.sort(Comparator.comparingDouble(o -> o.hitbox.x));
        
        int loreIndex = 0;
        for (GameObject obj : tempList) {
            if (obj.text.isEmpty() && loreIndex < loreTexts.length) {
                obj.text = loreTexts[loreIndex++];
            } else if (obj.text.isEmpty()) {
                obj.text = "...";
            }
            loreObjects.add(obj);
        }
        
        // --- TRAP OBJECTS (TMX OBJECT LAYER) ---
        List<TMXObject> trapObjs = level.getObjects("Traps");
        if (trapObjs != null) {
            for (TMXObject o : trapObjs)
                traps.add(new GameObject(o.x, o.y, o.width, o.height, 0));
        }
        
        // --- TRAP OBJECTS (TILE LAYER) ---
        int[][] trapGrid = level.getLayerData("Traps");
        if (trapGrid != null) {
            for (int y = 0; y < trapGrid.length; y++) {
                for (int x = 0; x < trapGrid[0].length; x++) {
                    if (trapGrid[y][x] != 0) {
                        int offset = (int)(Game.TILES_DEFAULT_SIZE * Game.SCALE / 2);
                        traps.add(new GameObject(
                            x * Game.TILES_DEFAULT_SIZE,
                            y * Game.TILES_DEFAULT_SIZE,
                            Game.TILES_DEFAULT_SIZE,
                            Game.TILES_DEFAULT_SIZE,
                            offset
                        ));
                    }
                }
            }
        }
        
        // --- ACID TILE TRAPS ---
        int[][] acidGrid = level.getLayerData("Acid");
        if (acidGrid != null) {
            for (int y = 0; y < acidGrid.length; y++) {
                for (int x = 0; x < acidGrid[0].length; x++) {
                    if (acidGrid[y][x] != 0) {
                        traps.add(new GameObject(
                            x * Game.TILES_DEFAULT_SIZE,
                            y * Game.TILES_DEFAULT_SIZE,
                            Game.TILES_DEFAULT_SIZE,
                            Game.TILES_DEFAULT_SIZE,
                            ""
                        ));
                    }
                }
            }
        }
    }

    // --- PASSIVE COLLISION CHECKS (DEATH / CHECKPOINT) ---
    public void checkObjectTouched(Player player) {
        for (GameObject t : traps) {
            if (t.hitbox.intersects(player.getHitbox())) {
                game.triggerDeath();
                return;
            }
        }
        for (GameObject lo : loreObjects) {
            if (lo.hitbox.intersects(player.getHitbox())) {
                game.setCheckpoint(lo.hitbox);
            }
        }
    }
    
    // --- INTERACTION CHECK (F KEY) ---
    public void checkInteraction(Player player) {
        for (GameObject lo : loreObjects) {
            if (lo.hitbox.intersects(player.getHitbox())) {
                game.getDialogueOverlay().showMessage(lo.text);
                game.setCheckpoint(lo.hitbox);
                player.resetDirBooleans();
                return;
            }
        }
    }

    // --- INTERACTION PROMPT RENDER ---
    public void draw(Graphics g, int xLvlOffset, int yLvlOffset) {
        Player player = game.getPlayer();
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 14));
        
        for (GameObject lo : loreObjects) {
            if (lo.hitbox.intersects(player.getHitbox())) {
                int textX = (int)(lo.hitbox.x - xLvlOffset) + (int)(lo.hitbox.width / 2) - 25;
                int textY = (int)(lo.hitbox.y - yLvlOffset) - 10;
                g.drawString("Press F", textX, textY);
            }
        }
    }
}
