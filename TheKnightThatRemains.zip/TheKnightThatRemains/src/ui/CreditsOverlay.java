package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import main.Game;
import main.Gamestate;

public class CreditsOverlay {

    private Game game;

    public CreditsOverlay(Game game) {
        this.game = game;
    }

    public void update() {}

    public void draw(Graphics g) {

        // --- BACKGROUND OVERLAY ---
        g.setColor(new Color(0, 0, 0, 220));
        g.fillRect(0, 0, Game.GAME_WIDTH, Game.GAME_HEIGHT);

        // --- TITLE ---
        g.setColor(Color.WHITE);
        g.setFont(new Font("Times New Roman", Font.BOLD, 30));
        String title = "CREDITS";
        int titleW = g.getFontMetrics().stringWidth(title);
        g.drawString(title, (Game.GAME_WIDTH - titleW) / 2, 50);

        // --- CREDITS DATA ---
        int startY = 90;
        int lineHeight = 18;

        String[] assets = {
            "Dungeon Platformer Tile Set (Pixel Art)",
            "Skeletons Pack",
            "Generic Dungeon Pack",
            "Basic 140 Tiles - Grassland and Mines",
            "Platformer Knight Hero"
        };

        String[] authors = {
            "by IncolGames",
            "by MonoPixelArt",
            "by Bakudas",
            "by Anokolisa",
            "by PixiVan"
        };

        // --- CREDITS RENDERING ---
        for (int i = 0; i < assets.length; i++) {

            g.setColor(new Color(255, 220, 100));
            g.setFont(new Font("Arial", Font.BOLD, 14));
            int assetW = g.getFontMetrics().stringWidth(assets[i]);
            g.drawString(assets[i], (Game.GAME_WIDTH - assetW) / 2, startY);

            startY += lineHeight;

            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.PLAIN, 12));
            int authW = g.getFontMetrics().stringWidth(authors[i]);
            g.drawString(authors[i], (Game.GAME_WIDTH - authW) / 2, startY);

            startY += lineHeight + 15;
        }

        // --- EXIT PROMPT ---
        g.setColor(Color.GRAY);
        g.setFont(new Font("Arial", Font.BOLD, 12));
        String exit = "Press ESC to Return";
        int exitW = g.getFontMetrics().stringWidth(exit);
        g.drawString(exit, (Game.GAME_WIDTH - exitW) / 2, Game.GAME_HEIGHT - 30);
    }

    // --- INPUT HANDLING ---
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
            Gamestate.state = Gamestate.MENU;
        }
    }
}
