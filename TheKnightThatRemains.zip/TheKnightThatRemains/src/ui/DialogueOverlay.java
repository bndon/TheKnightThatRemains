package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import main.Game;
import main.Gamestate;

public class DialogueOverlay {

    private Game game;
    private String fullText = "";
    private String currentText = "";
    private int tick = 0;
    private int charIndex = 0;
    private final int speed = 2;

    public DialogueOverlay(Game game) {
        this.game = game;
    }

    // --- MESSAGE INITIALIZATION ---
    public void showMessage(String text) {
        this.fullText = text;
        this.currentText = "";
        this.charIndex = 0;
        this.tick = 0;
        Gamestate.state = Gamestate.DIALOGUE;
    }

    // --- TEXT ANIMATION UPDATE ---
    public void update() {
        if (charIndex < fullText.length()) {
            tick++;
            if (tick >= speed) {
                tick = 0;
                currentText += fullText.charAt(charIndex);
                charIndex++;
            }
        }
    }

    public void draw(Graphics g) {

        int x = 50;
        int y = Game.GAME_HEIGHT - 150;
        int w = Game.GAME_WIDTH - 100;
        int h = 100;

        // --- DIALOGUE BACKGROUND ---
        g.setColor(new Color(0, 0, 0, 220));
        g.fillRect(x, y, w, h);
        g.setColor(Color.WHITE);
        g.drawRect(x, y, w, h);

        // --- TEXT RENDERING ---
        g.setFont(new Font("Arial", Font.PLAIN, 20));
        int textX = x + 20;
        int textY = y + 40;
        int maxLineWidth = w - 40;

        String[] words = currentText.split(" ");
        String line = "";

        for (String word : words) {
            String testLine = line + word + " ";
            int testWidth = g.getFontMetrics().stringWidth(testLine);

            if (testWidth > maxLineWidth) {
                g.drawString(line, textX, textY);
                line = word + " ";
                textY += 25;
            } else {
                line = testLine;
            }
        }
        g.drawString(line, textX, textY);

        // --- INPUT PROMPT ---
        if (charIndex >= fullText.length()) {
            g.setFont(new Font("Arial", Font.BOLD, 12));
            g.drawString("Press SPACE to close", x + w - 150, y + h - 15);
        }
    }

    // --- INPUT HANDLING ---
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            if (charIndex < fullText.length()) {
                currentText = fullText;
                charIndex = fullText.length();
            } else {
                Gamestate.state = Gamestate.PLAYING;
            }
        }
    }
}
