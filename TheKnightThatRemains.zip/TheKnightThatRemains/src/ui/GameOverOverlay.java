package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import main.Game;
import main.Gamestate;

public class GameOverOverlay {

    private Game game;
    private int timer = 0;
    private int alpha = 0;

    public GameOverOverlay(Game game) {
        this.game = game;
    }
    
    public void reset() {
        timer = 0;
        alpha = 0;
    }

    public void update() {
        timer++;
        if (timer > 20) { // Slight delay before fading in
            alpha += 2;
            if (alpha > 255) alpha = 255;
        }
    }

    public void draw(Graphics g) {
        // 1. Darken Background
        g.setColor(new Color(0, 0, 0, 150));
        g.fillRect(0, 0, Game.GAME_WIDTH, Game.GAME_HEIGHT);

        // 2. Setup Font
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setFont(new Font("Times New Roman", Font.BOLD, 60));
        
        String text = "YOU DIED";
        int textW = g.getFontMetrics().stringWidth(text);
        int x = (Game.GAME_WIDTH - textW) / 2;
        int y = Game.GAME_HEIGHT / 2;

        if (alpha > 0) {
            // 3. Draw Outline (Black)
            g.setColor(new Color(0, 0, 0, alpha));
            for (int i = -2; i <= 2; i++) {
                for (int j = -2; j <= 2; j++) {
                    if (i != 0 || j != 0) g.drawString(text, x + i, y + j);
                }
            }
            
            // 4. Draw Inner Text (Red)
            g.setColor(new Color(180, 0, 0, alpha));
            g.drawString(text, x, y);
            
            // 5. Draw "Press Space"
            if (alpha >= 255) {
                g.setFont(new Font("Arial", Font.PLAIN, 20));
                String sub = "Press SPACE to Respawn";
                int subW = g.getFontMetrics().stringWidth(sub);
                g.setColor(Color.WHITE);
                g.drawString(sub, (Game.GAME_WIDTH - subW) / 2, y + 60);
            }
        }
    }

    public void keyPressed(KeyEvent e) {
        if (alpha >= 255 && e.getKeyCode() == KeyEvent.VK_SPACE) {
            game.respawnPlayer();
        }
    }
}