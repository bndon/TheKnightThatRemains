package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import main.Game;
import main.Gamestate;
import utils.LoadSave;

public class Menu {

    // --- CORE REFERENCES ---
    private Game game;

    // --- VISUAL ASSETS ---
    private BufferedImage backgroundImg;

    // --- UI BUTTON BOUNDS ---
    private Rectangle btnNewGame, btnContinue, btnCredits, btnQuit;

    // --- BUTTON LAYOUT CONFIG ---
    private int btnW = 140;
    private int btnH = 40;
    private int btnX;

    // --- SAVE STATE FLAG ---
    private boolean hasSaveFile = false;

    public Menu(Game game) {
        this.game = game;
        initClasses();
    }

    // --- INITIALIZATION ---
    private void initClasses() {

        try {
            backgroundImg = LoadSave.GetSpriteAtlas(LoadSave.MENU_BACKGROUND);
        } catch (Exception e) {
            System.out.println("Menu Background not found.");
        }

        hasSaveFile = LoadSave.IsSaveFilePresent();

        btnX = Game.GAME_WIDTH / 2 - btnW / 2;
        int startY = Game.GAME_HEIGHT / 2 - 10;
        int spacing = 50;

        btnNewGame = new Rectangle(btnX, startY, btnW, btnH);
        btnContinue = new Rectangle(btnX, startY + spacing, btnW, btnH);
        btnCredits  = new Rectangle(btnX, startY + spacing * 2, btnW, btnH);
        btnQuit     = new Rectangle(btnX, startY + spacing * 3, btnW, btnH);
    }

    // --- SAVE FILE STATE REFRESH ---
    public void refreshSaveStatus() {
        hasSaveFile = LoadSave.IsSaveFilePresent();
    }

    public void update() {}

    public void draw(Graphics g) {

        // --- BACKGROUND RENDERING ---
        if (backgroundImg != null) {
            g.drawImage(backgroundImg, 0, 0, Game.GAME_WIDTH, Game.GAME_HEIGHT, null);
        } else {
            g.setColor(new Color(30, 30, 30));
            g.fillRect(0, 0, Game.GAME_WIDTH, Game.GAME_HEIGHT);
        }

        // --- TITLE RENDERING ---
        g.setFont(new Font("Times New Roman", Font.BOLD, 50));
        String title = "THE KNIGHT THAT REMAINS";
        int titleW = g.getFontMetrics().stringWidth(title);
        int titleX = Game.GAME_WIDTH / 2 - titleW / 2;
        int titleY = 120;

        g.setColor(Color.BLACK);
        g.drawString(title, titleX + 3, titleY + 3);
        g.setColor(Color.WHITE);
        g.drawString(title, titleX, titleY);

        // --- MENU BUTTONS ---
        drawButton(g, btnNewGame, "NEW GAME", true);
        drawButton(g, btnContinue, "CONTINUE", hasSaveFile);
        drawButton(g, btnCredits, "CREDITS", true);
        drawButton(g, btnQuit, "QUIT GAME", true);
    }

    // --- BUTTON RENDERING ---
    private void drawButton(Graphics g, Rectangle btn, String text, boolean active) {

        if (active) g.setColor(new Color(0, 0, 0, 180));
        else g.setColor(new Color(50, 50, 50, 180));
        g.fillRect(btn.x, btn.y, btn.width, btn.height);

        if (active) g.setColor(Color.WHITE);
        else g.setColor(Color.GRAY);
        g.drawRect(btn.x, btn.y, btn.width, btn.height);

        if (active) g.setColor(Color.WHITE);
        else g.setColor(Color.GRAY);

        g.setFont(new Font("Arial", Font.BOLD, 14));
        int textW = g.getFontMetrics().stringWidth(text);
        int textX = btn.x + (btn.width - textW) / 2;
        int textY = btn.y + (btn.height / 2) + 5;

        g.drawString(text, textX, textY);
    }

    // --- MOUSE INPUT HANDLING ---
    public void mousePressed(int x, int y) {

        if (btnNewGame.contains(x, y)) {
            game.resetGameForNewStart();
            Gamestate.state = Gamestate.PLAYING;

        } else if (btnContinue.contains(x, y)) {
            if (hasSaveFile) {
                game.loadGameData();
                Gamestate.state = Gamestate.PLAYING;
            }

        } else if (btnCredits.contains(x, y)) {
            Gamestate.state = Gamestate.CREDITS;

        } else if (btnQuit.contains(x, y)) {
            System.exit(0);
        }
    }
}
