package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import main.Game;
import main.Gamestate;

public class PauseOverlay {

    // --- CORE REFERENCES ---
    private Game game;

    // --- BUTTON BOUNDS ---
    private Rectangle btnResume, btnOptions, btnExit;

    // --- BUTTON SIZE CONFIG ---
    private int btnW = 200;
    private int btnH = 50;
    
    public PauseOverlay(Game game) {
        this.game = game;
        initBounds();
    }
    
    // --- BUTTON LAYOUT INITIALIZATION ---
    private void initBounds() {
        int startY = Game.GAME_HEIGHT / 2 - 100;
        int centerX = Game.GAME_WIDTH / 2 - btnW / 2;
        
        btnResume  = new Rectangle(centerX, startY, btnW, btnH);
        btnOptions = new Rectangle(centerX, startY + 70, btnW, btnH);
        btnExit    = new Rectangle(centerX, startY + 140, btnW, btnH);
    }

    public void update() {}

    public void draw(Graphics g) {

        // --- PAUSE OVERLAY BACKGROUND ---
        g.setColor(new Color(0, 0, 0, 150));
        g.fillRect(0, 0, Game.GAME_WIDTH, Game.GAME_HEIGHT);
        
        // --- PAUSE MENU BUTTONS ---
        drawButton(g, btnResume, "RESUME", true);
        drawButton(g, btnOptions, "OPTIONS (N/A)", false);
        drawButton(g, btnExit, "EXIT TO MENU", true);
    }
    
    // --- BUTTON RENDERING ---
    private void drawButton(Graphics g, Rectangle btn, String text, boolean active) {

        if (active) g.setColor(new Color(70, 70, 70));
        else g.setColor(new Color(40, 40, 40));
        g.fillRect(btn.x, btn.y, btn.width, btn.height);
        
        if (active) g.setColor(Color.WHITE);
        else g.setColor(Color.GRAY);
        g.drawRect(btn.x, btn.y, btn.width, btn.height);
        
        g.setFont(new Font("Arial", Font.BOLD, 18));
        int textWidth = g.getFontMetrics().stringWidth(text);
        g.drawString(text, btn.x + (btn.width - textWidth) / 2, btn.y + 32);
    }

    // --- MOUSE INPUT HANDLING ---
    public void mousePressed(int x, int y) {

        if (btnResume.contains(x, y)) {
            game.togglePause();

        } else if (btnOptions.contains(x, y)) {
            // Disabled

        } else if (btnExit.contains(x, y)) {
            game.resetGame();
            game.getMenu().refreshSaveStatus();
            Gamestate.state = Gamestate.MENU;
            game.togglePause();
        }
    }
}
