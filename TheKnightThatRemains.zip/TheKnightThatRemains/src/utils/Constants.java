package utils;

import main.Game;

public class Constants {
    
    // --- DIRECTION CONSTANTS ---
    public static class Directions {
        public static final int LEFT = 0;
        public static final int UP = 1;
        public static final int RIGHT = 2;
        public static final int DOWN = 3;
    }
    
    // --- PLAYER STATE & ANIMATION CONSTANTS ---
    public static class PlayerConstants {
        public static final int IDLE = 0;
        public static final int WALK = 1;
        public static final int RUN = 2;
        public static final int ATTACK_1 = 3;
        public static final int ATTACK_2 = 4;
        public static final int ATTACK_2_PHASE_1_RECOVER = 5;
        public static final int ATTACK_3 = 6;
        public static final int SHIELD_RAISE = 7;
        public static final int SHIELD_RAISE_WALK = 8;
        public static final int SWORD_RAISE = 9;
        public static final int CHANNELING_IDLE = 10;
        public static final int HIT_BACK = 11;
        public static final int HIT_FRONT = 12;
        public static final int ROLL = 13;
        public static final int JUMP = 14;
        public static final int FALL = 15;
        
        // --- PLAYER ANIMATION FRAME COUNTS ---
        public static int GetSpriteAmount(int player_action) {
            if (player_action == IDLE) return 5;
            else if (player_action == WALK) return 6;
            else if (player_action == RUN) return 6;
            else if (player_action == ATTACK_1) return 10;
            else if (player_action == ATTACK_2) return 11;
            else if (player_action == ATTACK_2_PHASE_1_RECOVER) return 4;
            else if (player_action == ATTACK_3) return 8;
            else if (player_action == SHIELD_RAISE) return 5;
            else if (player_action == SHIELD_RAISE_WALK) return 6;
            else if (player_action == SWORD_RAISE) return 10;
            else if (player_action == CHANNELING_IDLE) return 5;
            else if (player_action == HIT_BACK) return 5;
            else if (player_action == HIT_FRONT) return 6;
            else if (player_action == ROLL) return 11;
            else if (player_action == JUMP) return 4;
            else if (player_action == FALL) return 4;
            
            return 1;
        }
    }
    
    // --- ENEMY TYPE, STATE & SIZE CONSTANTS ---
    public static class EnemyConstants {
        public static final int SKELETON = 0;
        
        public static final int ATTACK_1 = 0;
        public static final int ATTACK_2 = 1;
        public static final int DEAD = 2;
        public static final int HIT = 3;
        public static final int IDLE = 4;
        public static final int WALK = 5;

        public static final int SKELETON_WIDTH_DEFAULT = 96;
        public static final int SKELETON_HEIGHT_DEFAULT = 64;
        
        // --- SCALED ENEMY DIMENSIONS ---
        public static final int SKELETON_WIDTH = (int) (SKELETON_WIDTH_DEFAULT * Game.ENEMY_SCALE);
        public static final int SKELETON_HEIGHT = (int) (SKELETON_HEIGHT_DEFAULT * Game.ENEMY_SCALE);
        
        // --- DRAW OFFSETS ---
        public static final int SKELETON_DRAWOFFSET_X = (int) (41 * Game.ENEMY_SCALE); 
        public static final int SKELETON_DRAWOFFSET_Y = (int) (18 * Game.ENEMY_SCALE);

        // --- ENEMY ANIMATION FRAME COUNTS ---
        public static int GetSpriteAmount(int enemy_type, int enemy_state) {
            switch (enemy_type) {
                case SKELETON:
                    switch (enemy_state) {
                        case ATTACK_1: return 9;
                        case ATTACK_2: return 8;
                        case DEAD: return 13;
                        case HIT: return 4;
                        case IDLE: return 7;
                        case WALK: return 9;
                    }
            }
            return 0;
        }
    }
}
