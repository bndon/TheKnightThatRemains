package utils;

import java.awt.geom.Rectangle2D;
import main.Game;

public class HelpMethods {

    // --- COLLISION CHECK: ENTITY MOVEMENT ---
    public static boolean CanMoveHere(float x, float y, float width, float height, int[][] lvlData) {
        if (!isSolid(x, y + 1, lvlData))
            if (!isSolid(x + width, y + height - 2, lvlData))
                if (!isSolid(x + width, y + 1, lvlData))
                    if (!isSolid(x, y + height - 2, lvlData))
                        return true;
        return false;
    }

    // --- TILE SOLIDITY CHECK ---
    public static boolean isSolid(float x, float y, int[][] lvlData) {
        int maxWidth = lvlData[0].length * Game.TILES_SIZE;
        int maxHeight = lvlData.length * Game.TILES_SIZE;

        if (x < 0 || x >= maxWidth) return true;
        if (y < 0 || y >= maxHeight) return true;

        float xIndex = x / Game.TILES_SIZE;
        float yIndex = y / Game.TILES_SIZE;

        if (yIndex >= lvlData.length || xIndex >= lvlData[0].length)
            return true;

        int value = lvlData[(int) yIndex][(int) xIndex];
        return value != 0;
    }

    // --- VERTICAL COLLISION RESOLUTION ---
    public static float GetEntityYPosUnderRoofOrAboveFloor(Rectangle2D.Float hitbox, float airSpeed) {
        int currentTileX = (int) ((hitbox.x + hitbox.width / 2) / Game.TILES_SIZE);
        int currentTileY = (int) (hitbox.y / Game.TILES_SIZE);

        if (airSpeed > 0) {
            int tileBelow = (int) (hitbox.y + airSpeed + hitbox.height) / Game.TILES_SIZE;
            return tileBelow * Game.TILES_SIZE - hitbox.height - 1;
        } else {
            return currentTileY * Game.TILES_SIZE;
        }
    }

    // --- FLOOR CHECK ---
    public static boolean IsEntityOnFloor(Rectangle2D.Float hitbox, int[][] lvlData) {
        if (!isSolid(hitbox.x, hitbox.y + hitbox.height + 1, lvlData))
            if (!isSolid(hitbox.x + hitbox.width, hitbox.y + hitbox.height + 1, lvlData))
                return false;
        return true;
    }
}
