package utils;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import main.Game;

public class LoadSave {

    // --- ASSET PATH CONSTANTS ---
    public static final String PLAYER_ATLAS = "player_sprites.png";
    public static final String LEVEL_ATLAS = "level_sprites.png";
    public static final String LEVEL_ONE_DATA = "level_one_data.png";
    public static final String SKELETON_ATLAS = "Skeleton.png";
    public static final String BOSS_ATLAS = "boss_knight.png";
    public static final String NEXT_KNIGHT_ATLAS  = "next_knight.png";
    public static final String MENU_BACKGROUND = "StartMenu.png";

    // --- SAVE FILE CONFIGURATION ---
    private static final String SAVE_FILE = "save_data.txt";

    // --- SPRITE / RESOURCE LOADING ---
    public static BufferedImage GetSpriteAtlas(String path) {
        BufferedImage img = null;
        String normalized = path.startsWith("/") ? path : "/" + path;

        try (InputStream is = LoadSave.class.getResourceAsStream(normalized)) {
            if (is == null)
                throw new RuntimeException("Image not found: " + normalized);
            img = ImageIO.read(is);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return img;
    }

    // --- SAVE GAME DATA ---
    public static void SaveGame(float x, float y, int health) {
        String data = x + "," + y + "," + health;

        try (FileWriter writer = new FileWriter(SAVE_FILE)) {
            writer.write(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- SAVE FILE VALIDATION ---
    public static boolean IsSaveFilePresent() {
        File file = new File(SAVE_FILE);
        return file.exists();
    }

    // --- LOAD GAME DATA ---
    public static float[] LoadGame() {
        File file = new File(SAVE_FILE);
        if (!file.exists())
            return null;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line = br.readLine();
            if (line == null)
                return null;

            String[] tokens = line.split(",");
            if (tokens.length != 3)
                return null;

            float x = Float.parseFloat(tokens[0]);
            float y = Float.parseFloat(tokens[1]);
            int health = Integer.parseInt(tokens[2]);

            // --- DATA SANITY CHECK ---
            if (health <= 0 || health > 100)
                return null;
            if (x < 0 || y < 0)
                return null;

            return new float[] { x, y, (float) health };
        } catch (Exception e) {
            return null;
        }
    }

    // --- LEVEL DATA LOADING (IMAGE-BASED) ---
    public static int[][] GetLevelData() {
        int[][] lvlData = new int[Game.TILES_IN_HEIGHT][Game.TILES_IN_WIDTH];
        BufferedImage img = GetSpriteAtlas(LEVEL_ONE_DATA);

        if (img != null) {
            for (int y = 0; y < img.getHeight(); ++y) {
                for (int x = 0; x < img.getWidth(); ++x) {
                    Color color = new Color(img.getRGB(x, y));
                    int value = color.getRed();

                    // --- TILE VALUE NORMALIZATION ---
                    if (value >= 48)
                        value = 0;

                    lvlData[y][x] = value;
                }
            }
        }
        return lvlData;
    }

    // --- LEVEL DATA LOADING (CSV-BASED) ---
    public static int[][] loadLevelFromCSV(String path) {
        List<int[]> rows = new ArrayList<>();

        try (InputStream is = LoadSave.class.getResourceAsStream("/" + path);
             BufferedReader br = new BufferedReader(new InputStreamReader(is))) {

            String line;
            while ((line = br.readLine()) != null) {
                String[] tokens = line.split(",");
                int[] row = new int[tokens.length];

                for (int i = 0; i < tokens.length; i++) {
                    row[i] = Integer.parseInt(tokens[i].trim()) - 1;
                }
                rows.add(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows.toArray(new int[0][]);
    }
}
