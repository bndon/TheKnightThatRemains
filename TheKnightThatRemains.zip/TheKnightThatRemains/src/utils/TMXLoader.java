package utils;

import java.io.InputStream;
import java.util.*;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;

public class TMXLoader {

    // --- TILESET METADATA ---
    public static class TilesetInfo {
        public final int firstGid;
        public String source;

        public TilesetInfo(int firstGid, String source) {
            this.firstGid = firstGid;
            this.source = source;
        }
    }

    // --- TMX OBJECT REPRESENTATION ---
    public static class TMXObject {
        public String name;
        public String type;
        public int x, y, width, height;
        public Map<String, String> properties = new HashMap<>();

        public TMXObject(String name, String type, int x, int y, int width, int height) {
            this.name = name;
            this.type = type;
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }
    }

    // --- TMX PARSED DATA CONTAINER ---
    public static class TMXData {
        public final Map<String, int[][]> layers;
        public final List<TilesetInfo> tilesets;
        public final Map<String, List<TMXObject>> objectGroups;

        public TMXData(Map<String, int[][]> layers,
                       List<TilesetInfo> tilesets,
                       Map<String, List<TMXObject>> objectGroups) {
            this.layers = layers;
            this.tilesets = tilesets;
            this.objectGroups = objectGroups;
        }
    }

    // --- MAIN TMX LOADING PIPELINE ---
    public static TMXData load(String tmxPath) {
        tmxPath = normalize(tmxPath);

        try (InputStream is = TMXLoader.class.getResourceAsStream(tmxPath)) {
            if (is == null)
                throw new RuntimeException("TMX not found: " + tmxPath);

            Document doc = DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder()
                    .parse(is);

            Element map = doc.getDocumentElement();
            int width = Integer.parseInt(map.getAttribute("width"));
            int height = Integer.parseInt(map.getAttribute("height"));

            // --- TILESET LOADING (TSX-BASED) ---
            List<TilesetInfo> tilesets = new ArrayList<>();
            NodeList tilesetNodes = map.getElementsByTagName("tileset");

            for (int i = 0; i < tilesetNodes.getLength(); i++) {
                Element ts = (Element) tilesetNodes.item(i);
                int firstGid = Integer.parseInt(ts.getAttribute("firstgid"));

                if (ts.hasAttribute("source")) {
                    String tsxPath = resolve(tmxPath, ts.getAttribute("source"));
                    tilesets.add(loadTSX(firstGid, tsxPath));
                }
            }

            // --- TILE LAYER PARSING (CSV ONLY) ---
            Map<String, int[][]> layers = new LinkedHashMap<>();
            NodeList layerNodes = map.getElementsByTagName("layer");

            for (int i = 0; i < layerNodes.getLength(); i++) {
                Element layer = (Element) layerNodes.item(i);
                String name = layer.getAttribute("name");
                Element data = (Element) layer.getElementsByTagName("data").item(0);

                if (!"csv".equals(data.getAttribute("encoding")))
                    throw new RuntimeException("Only CSV encoding is supported");

                String rawData = data.getTextContent().replaceAll("\\s+", "");
                String[] gids = rawData.split(",");

                int[][] grid = new int[height][width];
                for (int j = 0; j < gids.length; j++) {
                    long rawGid = Long.parseLong(gids[j].trim());

                    // --- STRIP FLIP FLAGS (TMX BITMASK) ---
                    grid[j / width][j % width] =
                            (int) (rawGid & ~(0xE0000000L));
                }
                layers.put(name, grid);
            }

            // --- OBJECT GROUP PARSING ---
            Map<String, List<TMXObject>> objectGroups = new HashMap<>();
            NodeList objGroupNodes = map.getElementsByTagName("objectgroup");

            for (int i = 0; i < objGroupNodes.getLength(); i++) {
                Element group = (Element) objGroupNodes.item(i);
                String groupName = group.getAttribute("name");
                List<TMXObject> objects = new ArrayList<>();

                NodeList objNodes = group.getElementsByTagName("object");
                for (int j = 0; j < objNodes.getLength(); j++) {
                    Element obj = (Element) objNodes.item(j);

                    String name = obj.getAttribute("name");
                    String type = obj.getAttribute("type");

                    int x = (int) Double.parseDouble(obj.getAttribute("x"));
                    int y = (int) Double.parseDouble(obj.getAttribute("y"));
                    int w = obj.hasAttribute("width")
                            ? (int) Double.parseDouble(obj.getAttribute("width"))
                            : 32;
                    int h = obj.hasAttribute("height")
                            ? (int) Double.parseDouble(obj.getAttribute("height"))
                            : 32;

                    TMXObject tmxObj = new TMXObject(name, type, x, y, w, h);

                    // --- CUSTOM PROPERTY EXTRACTION ---
                    NodeList propertiesList = obj.getElementsByTagName("properties");
                    if (propertiesList.getLength() > 0) {
                        NodeList props =
                                ((Element) propertiesList.item(0))
                                        .getElementsByTagName("property");

                        for (int k = 0; k < props.getLength(); k++) {
                            Element p = (Element) props.item(k);
                            tmxObj.properties.put(
                                    p.getAttribute("name"),
                                    p.getAttribute("value")
                            );
                        }
                    }
                    objects.add(tmxObj);
                }

                objectGroups.put(groupName, objects);
            }

            return new TMXData(layers, tilesets, objectGroups);

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load TMX", e);
        }
    }

    // --- TSX TILESET LOADER ---
    private static TilesetInfo loadTSX(int firstGid, String tsxPath) throws Exception {
        tsxPath = normalize(tsxPath);

        try (InputStream is = TMXLoader.class.getResourceAsStream(tsxPath)) {
            if (is == null)
                throw new RuntimeException("TSX not found: " + tsxPath);

            Document doc = DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder()
                    .parse(is);

            Element image = (Element)
                    doc.getDocumentElement()
                            .getElementsByTagName("image")
                            .item(0);

            return new TilesetInfo(
                    firstGid,
                    resolve(tsxPath, image.getAttribute("source"))
            );
        }
    }

    // --- PATH RESOLUTION (RELATIVE → ABSOLUTE RESOURCE PATH) ---
    private static String resolve(String base, String relative) {
        int lastSlash = base.lastIndexOf('/');
        String parentDir =
                (lastSlash == -1) ? "/" : base.substring(0, lastSlash + 1);

        String combined = parentDir + relative;
        List<String> parts = new ArrayList<>();

        for (String part : combined.split("/")) {
            if (part.isEmpty() || part.equals("."))
                continue;
            if (part.equals("..")) {
                if (!parts.isEmpty())
                    parts.remove(parts.size() - 1);
            } else {
                parts.add(part);
            }
        }
        return "/" + String.join("/", parts);
    }

    // --- RESOURCE PATH NORMALIZATION ---
    private static String normalize(String path) {
        return path.startsWith("/") ? path : "/" + path;
    }
}
